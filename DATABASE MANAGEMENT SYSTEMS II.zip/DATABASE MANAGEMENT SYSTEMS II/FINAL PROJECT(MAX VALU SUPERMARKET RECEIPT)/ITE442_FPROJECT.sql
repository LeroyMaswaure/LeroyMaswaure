create database Pro1;
use pro1;
CREATE TABLE users (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    
);
INSERT INTO `users` VALUES (100, 'zxc', 'asdfgh','');
-- ----------------------------
-- Table structure for branch
-- ----------------------------
DROP TABLE IF EXISTS `branch`;
CREATE TABLE `branch`  (
  `Branch_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Branch_Name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Branch_Address` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Branch_City` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Branch_Phone` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Branch_ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;
ALTER TABLE    branch
ADD CONSTRAINT AK_br UNIQUE (Branch_Name);
-- ----------------------------
-- Records of branch
-- ----------------------------
INSERT INTO `branch` VALUES (1, 'PATTANAKARN', '2559 Pattanakarn Rd','Bangkok', '0-2322-7003-4');
INSERT INTO `branch` VALUES (2, 'RAMA 9 THE NINE', '999/1 Rama 9 Rd.','Bangkok', '0-2318-5118-9');
INSERT INTO `branch` VALUES (3, 'PATTANAKARN 20', '206 Soi Pattanakarn 20', 'Bangkok', '0-2318-6893-4');

-- ----------------------------
-- Table structure for cashier
-- ----------------------------
DROP TABLE IF EXISTS `cachier`;
CREATE TABLE `cashier`  (
  `Cashier_ID` int(11) NOT NULL AUTO_INCREMENT,
  `FName` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `M_Name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `L_Name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  Password varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Cashier_ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;
ALTER TABLE    cashier
ADD CONSTRAINT AK_PW UNIQUE (Username);
-- ----------------------------
-- Records of cashier
-- ----------------------------
INSERT INTO `cashier` VALUES (1, 'Yen', 'Hai', 'Nguyen', 'admin', 'admin');
INSERT INTO `cashier`(FName,M_Name,L_Name,Username) VALUES ('Yuni', 'Nguyen', 'yuninguyen', 'a123456');
INSERT INTO `cashier`(FName,M_Name,L_Name,Username) VALUES ('shek', 'kads', 'mun', 'asdfgh');
-- ----------------------------
-- Table structure for terminal
-- ----------------------------
DROP TABLE IF EXISTS `terminal`;
CREATE TABLE `terminal`  (
  `Terminal_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Terminal_Num` int(11) NOT NULL,
  `Branch_ID` int(11) NOT NULL,
  
  PRIMARY KEY (`Terminal_ID`) USING BTREE,
  INDEX `branch_terminal_fk`(`Branch_ID`) USING BTREE,
  CONSTRAINT `branch_terminal_fk` FOREIGN KEY (`Branch_ID`) REFERENCES `branch` (`Branch_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;
ALTER TABLE    terminal
ADD CONSTRAINT AK_IC UNIQUE (Terminal_Num);
-- ----------------------------
-- Records of terminal
-- ----------------------------
INSERT INTO `terminal` VALUES (1, 1, 1);
INSERT INTO `terminal` VALUES (2, 2, 1);
INSERT INTO `terminal` VALUES (3, 3, 1);
INSERT INTO `terminal` VALUES (4, 4, 1);
INSERT INTO `terminal` VALUES (5, 5, 1);


-- ----------------------------
-- Table structure for items_categories
-- ----------------------------
DROP TABLE IF EXISTS `items_categories`;
CREATE TABLE `items_categories`  (
  `Category_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Category_Name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Category_ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;
ALTER TABLE    items_categories
ADD CONSTRAINT AK_IC UNIQUE (Category_Name);
-- ----------------------------
-- Records of items_categories
-- ----------------------------
INSERT INTO `items_categories` VALUES (1, 'Fresh Food');
INSERT INTO `items_categories` VALUES (2, 'Food');
INSERT INTO `items_categories` VALUES (3, 'Beverages');
INSERT INTO `items_categories` VALUES (4, 'Snack & Sweets');

-- ----------------------------
-- Table structure for items_sub_categories
-- ----------------------------
DROP TABLE IF EXISTS `items_sub_categories`;
CREATE TABLE `items_sub_categories`  (
  `Category_ID` int(11) NULL DEFAULT NULL,
  `Sub_Category_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Sub_Category_Name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Sub_Category_ID`) USING BTREE,
  INDEX `category_sub_fl`(`Category_ID`) USING BTREE,
  CONSTRAINT `category_fk` FOREIGN KEY (`Category_ID`) REFERENCES `items_categories` (`Category_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;
ALTER TABLE    items_sub_categories
ADD CONSTRAINT AK_ISC UNIQUE (Sub_Category_Name);   
 -- ---------------------------
 -- Records of items_sub_categories
-- ----------------------------
INSERT INTO `items_sub_categories` VALUES (1, 1, 'Vegetable & Fruit');
INSERT INTO `items_sub_categories` VALUES (1, 2, 'Meat & Seafood');
INSERT INTO `items_sub_categories` VALUES (1, 3, 'Cheese & Sausage');
INSERT INTO `items_sub_categories` VALUES (1, 4, 'Frozen');
INSERT INTO `items_sub_categories` VALUES (1, 5, 'Bakery');
INSERT INTO `items_sub_categories` VALUES (2, 6, 'Cooking Ingredients');
INSERT INTO `items_sub_categories` VALUES (2, 7, 'Import Product');
INSERT INTO `items_sub_categories` VALUES (2, 8, 'Rice/ Grains / Herbs/ Dry Fruits');
INSERT INTO `items_sub_categories` VALUES (3, 9, 'Soft Drink');
INSERT INTO `items_sub_categories` VALUES (3, 10, 'Water');
INSERT INTO `items_sub_categories` VALUES (4, 11, 'Snack');
INSERT INTO `items_sub_categories` VALUES (4, 12, 'Chocolate/ Sweet');
 -- ------------------
 -- items_sub_categories view
-- ----------------------------
DROP VIEW IF EXISTS `View_items_sub_categories`;
CREATE VIEW View_items_sub_categories AS
SELECT items_sub_categories.Sub_Category_ID, items_sub_categories.Sub_Category_Name,items_categories.Category_Name
FROM items_sub_categories, items_categories
WHERE items_sub_categories.Category_ID = items_categories.Category_ID 
ORDER BY items_sub_categories.Category_ID;

-- ----------------------------
-- Table structure for items
-- ----------------------------
DROP TABLE IF EXISTS `items`;
CREATE TABLE `items`  (
  `Item_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Sub_Category_ID` int(11) NOT NULL,
  `Item_Name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Unit_Price` decimal(10, 2) NOT NULL,
  `Quantity` int(11) NOT NULL,
  PRIMARY KEY (`Item_ID`) USING BTREE,
  INDEX `sub_category_item_fk`(`Sub_Category_ID`) USING BTREE,
  CONSTRAINT `sub_category_item_fk` FOREIGN KEY (`Sub_Category_ID`) REFERENCES `items_sub_categories` (`Sub_Category_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 43 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;
ALTER TABLE    items
ADD CONSTRAINT AK_I UNIQUE (Item_Name); 
-- ----------------------------
-- Records of items
-- ----------------------------
INSERT INTO `items` VALUES (1, 1, 'Banana Pack 4', 32.00, 101);
INSERT INTO `items` VALUES (2, 1, 'Kinri Watermelon per KG', 23.00, 150);
INSERT INTO `items` VALUES (3, 1, 'Cucumber per Pack\r\n', 15.00, 50);
INSERT INTO `items` VALUES (4, 1, 'TIPCO Squeeze Fuji Apple & Mixed Grape Juice 1 L', 87.00, 100);
INSERT INTO `items` VALUES (5, 1, 'Green Apple No.163 Pack 6', 59.00, 50);
INSERT INTO `items` VALUES (6, 2, 'Big C Minced Pork Grade A per KG\r\n', 170.00, 50);
INSERT INTO `items` VALUES (7, 2, 'Nile Tilapia Size XL (0.5-1 KG/PC) per PC\r\n', 69.00, 50);
INSERT INTO `items` VALUES (8, 2, 'Pork Spare Ribs per KG\r\n', 180.00, 50);
INSERT INTO `items` VALUES (9, 2, 'Big C Minced Chicken Fillet per KG\r\n', 110.00, 50);
INSERT INTO `items` VALUES (10, 3, 'JPM Sausage Gold Vienna Pork & Chicken Sausage 320 G.\r\n', 49.00, 100);
INSERT INTO `items` VALUES (11, 3, 'CASINO Emmental Cheese 300 G\r\n', 225.00, 50);
INSERT INTO `items` VALUES (12, 3, 'Philadelphia Cream Cheese Original Block 250 G\r\n', 119.00, 50);
INSERT INTO `items` VALUES (13, 3, 'BMP Smoked Bacon 150 G\r\n', 89.00, 100);
INSERT INTO `items` VALUES (14, 3, 'TGM Roast Ham 140 G\r\n', 49.00, 100);
INSERT INTO `items` VALUES (15, 4, 'JADE DRAGON Cream Bun 333 G\r\n', 72.00, 120);
INSERT INTO `items` VALUES (16, 4, 'JADE DRAGON Shrimp Ha-Kao 216 G\r\n', 72.00, 120);
INSERT INTO `items` VALUES (17, 4, 'THE BEEF HOUSE GROUND BEEF FROZEN 500 G\r\n', 177.00, 120);
INSERT INTO `items` VALUES (18, 5, 'Farmhouse Wholewheat Bread 500 G\r\n', 40.00, 200);
INSERT INTO `items` VALUES (19, 5, 'Farmhouse Sandwich Bread 480 G\r\n', 36.00, 200);
INSERT INTO `items` VALUES (20, 5, 'Farmhouse Wholewheat Bread 250 G\r\n', 22.00, 200);
INSERT INTO `items` VALUES (21, 6, 'Maekrua Oyster Sauce 600 ML.\r\n', 38.00, 30);
INSERT INTO `items` VALUES (22, 6, 'Mitr Phol Pure Refined Sugar 1 KG.\r\n', 22.00, 89);
INSERT INTO `items` VALUES (23, 6, 'Wangkanai Special White Sugar 1 KG.\r\n', 21.00, 90);
INSERT INTO `items` VALUES (24, 7, 'McGarrett Multi Fruit Muesli 500 g.\r\n', 110.00, 56);
INSERT INTO `items` VALUES (25, 7, 'Perrier Lemon Sparkling Mineral Water 330 ml.\r\n', 49.00, 50);
INSERT INTO `items` VALUES (26, 7, 'Cirio Chopped Tomatoes 400 g.\r\n', 63.00, 50);
INSERT INTO `items` VALUES (27, 8, 'Banjarong Jasmine rice 5 kg\r\n', 208.00, 50);
INSERT INTO `items` VALUES (28, 8, 'Royal Umbrella 100% White Jasmine Rice Size 5 kg.\r\n', 259.00, 40);
INSERT INTO `items` VALUES (30, 8, 'Royal Umbrella Hom Rice 5 KG.\r\n', 155.00, 30);
INSERT INTO `items` VALUES (31, 9, 'Chang Soda Water 325 ML. Pack 6\r\n', 42.00, 56);
INSERT INTO `items` VALUES (32, 9, 'Singha Soda Water 325 ML. x 6\r\n', 46.00, 50);
INSERT INTO `items` VALUES (33, 9, 'Singha Soda Water 325 ml. Pack 24\r\n', 170.00, 30);
INSERT INTO `items` VALUES (34, 10, 'Nestle Pure Life Drinking Water 1.5 L. Pack 6\r\n', 49.00, 100);
INSERT INTO `items` VALUES (35, 10, 'Bigc Drinking water 6 L.\r\n', 29.00, 100);
INSERT INTO `items` VALUES (36, 10, 'Crystal Drinking Water 600 CC. Pack 12\r\n', 49.00, 150);
INSERT INTO `items` VALUES (37, 11, 'Bento Crispy Squid contains 6.8 grams,12 packs', 46.00, 100);
INSERT INTO `items` VALUES (38, 11, 'Bento Squid Snack Sweet & Spicy Flavor 5 G. Pack 12\r\n', 46.00, 100);
INSERT INTO `items` VALUES (39, 11, 'Bento Chilli Style Thai Size 20 g.\r\n', 19.00, 150);
INSERT INTO `items` VALUES (40, 12, 'Hao Li Yuan Chewy Milk Candy Taro Flavor 70 g.\r\n', 18.00, 100);
INSERT INTO `items` VALUES (41, 12, 'Nude Candy Raspberry Flavor Sugar Free Size 15.5 g.\r\n', 49.00, 150);
INSERT INTO `items` VALUES (42, 12, 'Casino Dark Chocolate 100 g.\r\n', 139.00, 150);
 -- ------------------
 -- items view
-- ----------------------------
DROP VIEW IF EXISTS `View_items`;
CREATE VIEW View_items AS
SELECT items.Item_ID, items.Item_Name, items_sub_categories.Sub_Category_Name, items.Unit_Price, items.Quantity
FROM items, items_sub_categories
WHERE items.Sub_Category_ID= items_sub_categories.Sub_Category_ID 
ORDER BY items.sub_Category_ID;


SELECT items.Item_ID, items.Item_Name, items_sub_categories.Sub_Category_Name, items.Unit_Price, items.Quantity- invoice_details.order_item_quantity 
FROM View_items, invoice_details, items, items_sub_categories
WHERE  items.item_ID = invoice_details.item_ID and items.Sub_Category_ID= items_sub_categories.Sub_Category_ID 
ORDER BY items.item_ID;
-- ----------------------------
-- Table structure for customers
-- ----------------------------
DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers`  (
  `Customer_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Customer_FName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
   `Customer_MName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
    `Customer_LName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `Member_registration_date` date NULL DEFAULT NULL,
  PRIMARY KEY (`Customer_ID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of customers
-- ----------------------------
INSERT INTO `customers` VALUES (1, 'Anonymous', '', '',  '2019-12-01');
INSERT INTO `customers` VALUES (2, 'Hoan', 'Thi','Ngo',  '2018-05-11');
INSERT INTO `customers` VALUES (3, 'Thao','Phuong','Le', '2018-10-07');
INSERT INTO `customers` VALUES (4, 'shek','kads','mun', '2020-01-01');
INSERT INTO `customers` VALUES (5, 'bob','kdan','mat', '2020-02-01');

DROP VIEW IF EXISTS `loyolalty_Point_card`;
CREATE VIEW loyolalty_Point_card AS
SELECT invoice.Transaction_ID, customers.Customer_FName, customers.Customer_MName, invoice.Customer_EarnPoint, customers.Balance_Points, (invoice.Customer_EarnPoint +customers.Balance_Points)
FROM invoice, customers
WHERE invoice.customer_ID = customers.Customer_ID
ORDER BY invoice.Transaction_ID;

-
-- ----
-- Table structure for VAT 
-- ----
DROP TABLE IF EXISTS `VAT`;
CREATE TABLE `VAT` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Year` year NOT NULL,
  `Percentage` int(10)  NOT NULL,
  PRIMARY KEY (`id`)USING BTREE
  )  ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;
ALTER TABLE    VAT
ADD CONSTRAINT AK_VT UNIQUE (`Year`);
-- ----------------------------
-- Records of VAT
-- ----------------------------
INSERT INTO `VAT`VALUES (1,'2019', 7);
INSERT INTO `VAT` VALUES (2,'2020', 7);

-- ----------------------------
-- Table structure for invoice
-- ----------------------------
DROP TABLE IF EXISTS `invoice`;
CREATE TABLE `invoice`  (
  `Transaction_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Transaction_Date` date NOT NULL,
  `Transaction_time` time NOT NULL,
  `Terminal_ID` int(11) NOT NULL,
  `Cashier_ID` int(11) NOT NULL,
  `Customer_ID` int(11) NULL DEFAULT NULL,
  `Customer_EarnPoint` int(11) NULL DEFAULT NULL,
  `Payment_Type` enum('Cash','Debit/Credit Card') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  
  PRIMARY KEY (`Transaction_ID`) USING BTREE,
   INDEX `ter_invoice_fk`(`Terminal_ID`) USING BTREE,
   INDEX `cashier_invoice_fk`(`Cashier_ID`) USING BTREE,
   INDEX `customer_invoice_fk`(`Customer_ID`) USING BTREE,
   CONSTRAINT `cashier_invoice_fl`  FOREIGN KEY (`Cashier_ID`) REFERENCES `cashier` (`Cashier_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `customer_invoice_fl`  FOREIGN KEY (`Customer_ID`) REFERENCES `customers` (`Customer_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `pos_invoice_fk`  FOREIGN KEY (`TERMINAL_ID`) REFERENCES `TERMINAL` (`TERMINAL_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;
 
-- ----------------------------
-- Records of invoice
-- ----------------------------
INSERT INTO `invoice` VALUES (1, '2020-01-26', '20:06:07', 1, 1, 1, 0, 'Cash');
INSERT INTO `invoice` VALUES (2, '2020-02-26', '21:06:07', 2, 1, 3, 1, 'Cash');
INSERT INTO `invoice` VALUES (3, '2021-02-10', '15:10:07', 3, 1, 2, 10, 'Debit/Credit Card');

-- ------------------
 -- invoice view
-- ----------------------------
DROP VIEW IF EXISTS `View_invoice`;
CREATE VIEW View_invoice AS
SELECT invoice.Transaction_ID, invoice.Transaction_Date, invoice.Transaction_time, Terminal.Terminal_ID, Cashier.Fname, Customers.Customer_FName, invoice.Customer_EarnPoint, invoice.Payment_Type
FROM  invoice, Terminal, Cashier, Customers
WHERE invoice.Cashier_ID = Cashier.Cashier_ID AND invoice.Customer_ID = Customers.Customer_ID AND invoice.Terminal_ID =Terminal.Terminal_ID
ORDER BY invoice.Transaction_ID;

-- ----------------------------
-- Table structure for invoice_details
-- ----------------------------
DROP TABLE IF EXISTS `invoice_details`;
CREATE TABLE `invoice_details`  (
  `Transaction_ID` int(11) NOT NULL,
  `Item_ID` int(11) NOT NULL,
  `order_item_quantity` int(11) NOT NULL,
  `order_item_price` decimal(10, 2) NULL DEFAULT NULL,
  PRIMARY KEY (`Transaction_ID`, `Item_ID`) USING BTREE,
  INDEX `item_invoice_fk`(`Item_ID`) USING BTREE)
  ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Compact;
 ALTER TABLE invoice_details ADD (CONSTRAINT `item_invoice_fk` FOREIGN KEY (`Item_ID`) REFERENCES `items` (`Item_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT);
 ALTER TABLE invoice_details ADD (CONSTRAINT `transaction_invoice_fk` FOREIGN KEY (`Transaction_ID`) REFERENCES `invoice` (`Transaction_ID`) ON DELETE RESTRICT ON UPDATE RESTRICT);
-- ----------------------------
-- Records of invoice_details
-- ----------------------------
INSERT INTO `invoice_details` VALUES (1, 1, 10, 32.00);
INSERT INTO `invoice_details` VALUES (2, 2, 12, 23.00);
INSERT INTO `invoice_details` VALUES (3, 3, 10, 45.00);

-- ------------------
 -- invoice_details view
-- ----------------------------
DROP VIEW  IF EXISTS `View_invoice_details`;
CREATE VIEW View_invoice_details AS
SELECT invoice_details.Transaction_ID, items.Item_Name,vat.Percentage, invoice_details.order_item_quantity, invoice_details.order_item_price,(invoice_details.order_item_quantity * invoice_details.order_item_price*0.7 )
FROM  invoice_details, invoice, items, vat
WHERE invoice_details.Transaction_ID = invoice.Transaction_ID AND invoice_details.Item_ID = items.Item_ID 
ORDER BY invoice_details.Transaction_ID;

-- ----------------------------
-- Table structure for tbllogactivity
-- ----------------------------
DROP TABLE IF EXISTS `tbllogactivity`;
CREATE TABLE `tbllogactivity`  (
  `logDateTime` datetime(0) NOT NULL COMMENT 'Date and Time of Activity',
  `logActivity` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'Activity : Insert / Update / Delete',
  `logTableName` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'Table Activity\n',
  `logDetail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'Detail of the activity',
  `logUser` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'User who do an activity.',
  PRIMARY KEY (`logDateTime`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'This table keeps activities of users' ROW_FORMAT = Compact;

-- ----------------------------
-- Triggers structure for table branch
-- ----------------------------
DROP TRIGGER IF EXISTS `DeleteActivityBranch`;
delimiter ;;
CREATE TRIGGER `DeleteActivityBranch` BEFORE DELETE ON `branch` FOR EACH ROW BEGIN
	INSERT INTO TBLLOGACTIVITY (logDateTime,logActivity,logTableName,logDetail,logUser)
    VALUES (NOW(),'DELETE','BRANCH',CONCAT('DELETE ROW : ',OLD.BRANCH_ID,'/',OLD.BRANCH_NAME,'/',OLD.BRANCH_ADDRESS,'/',OLD.BRANCH_CITY,'/',OLD.BRANCH_PHONE),CURRENT_USER);
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table cashier
-- ----------------------------
DROP TRIGGER IF EXISTS `InsertActivityUsers`;
delimiter ;;
CREATE TRIGGER `InsertActivityUsers` AFTER INSERT ON `users` FOR EACH ROW BEGIN
	INSERT INTO TBLLOGACTIVITY (logDateTime,logActivity,logTableName,logDetail,logUser)
    VALUES (NOW(),'Insert','User',CONCAT('NEW ROW : ',NEW.id,'/',NEW.username, '/',NEW.password, '/', NEW.created_at), CURRENT_USER);
END
;;
delimiter ;



SET FOREIGN_KEY_CHECKS = 1;




-- //////////////////////////////
DROP TRIGGER IF EXISTS `UpdateActivityUsers`;
delimiter ;;
CREATE TRIGGER `UpdateActivityUsers` AFTER UPDATE ON `users` FOR EACH ROW BEGIN
	INSERT INTO TBLLOGACTIVITY (logDateTime,logActivity,logTableName,logDetail,logUser)
    VALUES (NOW(),'UPDATE','users',CONCAT('UPDATE ROW : ','id OLD-NEW: ',OLD.id,'-',NEW.id,'/',
    'username OLD-NEW: ',OLD.username,'-',NEW.username,'/','password OLD-NEW: ',OLD.password,'-',NEW.password,'/' ,
    'create_at OLD-NEW: ',OLD.created_at,'-',NEW.created_at),CURRENT_USER);
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table branch
-- ----------------------------
DROP TRIGGER IF EXISTS `DeleteActivityUsers`;
delimiter ;;
CREATE TRIGGER `DeleteActivityUsers` BEFORE DELETE ON `users` FOR EACH ROW BEGIN
	INSERT INTO TBLLOGACTIVITY (logDateTime,logActivity,logTableName,logDetail,logUser)
    VALUES (NOW(),'DELETE','users',CONCAT('DELETE ROW : ',OLD.username,'/',OLD.password,'/',OLD.created_at),CURRENT_USER);
END
;;
delimiter ;

-- ----------------------------
-- Triggers structure for table cashier
-- ----------------------------
DROP TRIGGER IF EXISTS `InsertActivityUsers`;
delimiter ;;
CREATE TRIGGER `InsertActivityUsers` AFTER INSERT ON `users` FOR EACH ROW BEGIN
	INSERT INTO TBLLOGACTIVITY (logDateTime,logActivity,logTableName,logDetail,logUser)
    VALUES (NOW(),'INSERT','users',CONCAT('NEW ROW : ',NEW.username,'/',NEW.password,'/',NEW.created_at), CURRENT_USER);
END
;;
