<?php include ('header.php'); ?>
<?php include ("config.php");

//Because we receive parameters from addmember_form.php by Method post ,we have to receive with $_POST
$Transaction_ID = trim($_POST['Transaction_ID']);
$Item_ID = trim($_POST['Item_ID']);
$Seliing_Quantity = trim($_POST['Seliing_Quantity']);

$sql = "INSERT INTO invoice_details (Transaction_ID, Item_ID, Seliing_Quantity) VALUES ('{$Transaction_ID}', '{$Item_ID}', '{$Seliing_Quantity}')";

?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Invoice Details</li>
        </ol>

        <!-- DataTables Employees -->
        <div class="card mb-3">
            <div class="card-header clearfix">
                <h2>Add New Invoice Details</h2>
            </div>
                    <table>
                     <tr>
                        <td style="text-align: center;">
                            <?php
                            // If insert data successfully, show information and redirect to users.php
                            if($link->query($sql) == TRUE){
                                echo "<div id='message'>New record created successfully <hr/>Please wait to redirect...</div>";
                                echo "<meta http-equiv='refresh' content='1;url=../invoice_details.php'>"; // Redirect to users.php
                            } else {
                                echo "<div id='message'>Error: " . $sql . "<br>" . $link->error ."<hr/>Please wait to redirect...</div>";
                                echo "<meta http-equiv='refresh' content='1;url=../invoice_details.php'>"; // Redirect to users.php
                            }
                            ?>
                        </td>
                    </tr>
                </table>
            </div>
        <?php $link->close(); ?>
    </div>
</div>
<?php include ('footer.php'); 