<?php include ('header.php'); ?>
<?php include ("config.php");

$Item_Code = trim($_GET['id']); // Sent id by method GET , receive with $_GET

$sql = "DELETE FROM View_invoice_details WHERE Item_ID ='{$Item_ID}'";

?>
?>
<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Invoice Details</li>
        </ol>

        <!-- DataTables Employees -->
        <div class="card mb-3">
            <div class="card-header clearfix">
                <h2>Delete Invoice Details</h2>
            </div>
                    <table width="100%" cellpadding="5" cellspacing="5">
                     <tr>
                        <td style="text-align: center;">
                        <?php
                        // If data is deleted successfully , show information and redirect to index.php
                        if($link->query($sql) == TRUE){
                            echo "<div id='message'>Record deleted successfully <hr/>Please wait to redirect...</div>";
                            echo "<meta http-equiv='refresh' content='1;url=../invoice_details.php'>"; // Redirect to index.php
                        } else {
                            echo "<div id='message'>Error: " . $sql . "<br>" . $link->error ."<hr/>Please wait to redirect...</div>";
                            echo "<meta http-equiv='refresh' content='1;url=../invoice_details.php'>"; // Redirect to index.php
                        }
                        ?>
                        </td>
                    </tr>
                </table>
            </div>
        <?php $link->close(); ?>
    </div>
</div>
<?php include ('footer.php'); ?>