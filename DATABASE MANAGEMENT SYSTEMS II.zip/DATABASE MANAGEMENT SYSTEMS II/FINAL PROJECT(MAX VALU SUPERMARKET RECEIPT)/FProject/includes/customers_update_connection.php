<?php include ("config.php");

// Sent from editmember_form.php by Method post , receive with $_POST
$Customer_ID = $_POST['id'];
$Customer_FName = trim($_POST['Customer_FName']);
$Customer_MName = trim($_POST['Customer_MName']);
$Customer_LName = trim($_POST['Customer_LName']);
$Member_registration_date = trim($_POST['Member_registration_date']);

// ตรวจสอบว่ามีการแก้ไข Password ไหม

$sql = "UPDATE customers SET Customer_ID ='{$Customer_ID}',Customer_FName='{$Customer_FName}', Customer_MName='{$Customer_MName}', Customer_LName='{$Customer_LName}', Member_registration_date='{$Member_registration_date}' WHERE Customer_ID='{$Customer_ID}'";
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Dashboard - Max Value Supermarket</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body>
<div id="content-wrapper">
    <div class="container-fluid">
            <div class="card-body" style="text-align: center;">
                        <?php
                        // If member's data is updated successfully, show information and redirect to customers.php
                        if($link->query($sql) == TRUE){
                            echo "<div id='message'>Record updated successfully!</div>";
                            echo "<meta http-equiv='refresh' content='1;url=../customers.php'>"; // Redirect to customers.php
                        } else {
                            echo "<div id='message'>Error: " . $sql . "<br>" . $l->error ."</div>";
                            echo "<meta http-equiv='refresh' content='1;url=../customers.php'>"; // Redirect to customers.php
                        }
                        ?>
            </div>
    </div>
        <?php $link->close(); ?>
</div>
</body>
</html>