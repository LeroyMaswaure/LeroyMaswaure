<?php include ("config.php");

//Because we receive parameters from addmember_form.php by Method post ,we have to receive with $_POST
$Discount_ID = trim($_POST['Discount_ID']);
$Item_ID = trim($_POST['Item_ID']);
$Start_Date = trim($_POST['Start_Date']);
$End_Date = trim($_POST['End_Date']);
$Discount_Type = trim($_POST['Discount_Type']);
$Amount = trim($_POST['Amount']);
$Coupon_Code = trim($_POST['Coupon_Code']);
$Status = trim($_POST['Status']);

$sql = "INSERT INTO promotion (Discount_ID, Item_ID, Start_Date, End_Date, Discount_Type, Amount, Coupon_Code, Status) VALUES ('{$Discount_ID}', '{$Item_ID}', '{$Start_Date}', '{$End_Date}', '{$Discount_Type}', '{$Amount}', '{$Coupon_Code}', '{$Status}')";

?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Dashboard - Max Value Supermarket</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body>
<div id="content-wrapper">
    <div class="container-fluid">
            <div class="card-body" style="text-align: center;">
                            <?php
                            // If insert data successfully, show information and redirect to promotion.php
                            if($link->query($sql) == TRUE){
                                echo "<div id='message'>New record created successfully!</div>";
                                echo "<meta http-equiv='refresh' content='1;url=../promotion.php'>"; // Redirect to promotion.php
                            } else {
                                echo "<div id='message'>Error: " . $sql . "<br>" . $link->error ."</div>";
                                echo "<meta http-equiv='refresh' content='1;url=../promotion.php'>"; // Redirect to promotion.php
                            }
                            ?>
            </div>
    </div>
        <?php $link->close(); ?>
</div>
</body>
</html>