<?php include ('header.php'); ?>
<?php include ("config.php");

//Because we receive parameters from addmember_form.php by Method post ,we have to receive with $_POST
$Transaction_ID = trim($_POST['Transaction_ID']);
$Transaction_Date = trim($_POST['Transaction_Date']);
$Transaction_time = trim($_POST['Transaction_time']);
$Terminal_ID = trim($_POST['Terminal_ID']);
$Cashier_ID = trim($_POST['Cashier_ID']);
$Customer_ID = trim($_POST['Customer_ID']);
$Customer_EarnPoint = trim($_POST['Customer_EarnPoint']);
$Payment_Type = trim($_POST['Payment_Type']);


$sql = "INSERT INTO View_invoice (Transaction_ID, Transaction_Date, Transaction_time, Terminal_ID, Cashier_ID, Customer_ID, Customer_EarnPoint, Payment_Type) VALUES ('{$Transaction_ID}','{$Transaction_Date}', '{$Transaction_time}', '{$Terminal_ID}',  '{$Cashier_ID}', '{$Terminal_ID}', '{$Customer_ID}', '{$Customer_EarnPoint}', '{$Payment_Type}')";

?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Invoice</li>
        </ol>

        <!-- DataTables Employees -->
        <div class="card mb-3">
            <div class="card-header clearfix">
                <h2>Add New Invoice</h2>
            </div>
                    <table>
                     <tr>
                        <td style="text-align: center;">
                            <?php
                            // If insert data successfully, show information and redirect to users.php
                            if($link->query($sql) == TRUE){
                                echo "<div id='message'>New record created successfully <hr/>Please wait to redirect...</div>";
                                echo "<meta http-equiv='refresh' content='10;url=../invoice.php'>"; // Redirect to users.php
                            } else {
                                echo "<div id='message'>Error: " . $sql . "<br>" . $link->error ."<hr/>Please wait to redirect...</div>";
                                echo "<meta http-equiv='refresh' content='10;url=../invoice.php'>"; // Redirect to users.php
                            }
                            ?>
                        </td>
                    </tr>
                </table>
            </div>
        <?php $link->close(); ?>
    </div>
</div>
<?php include ('footer.php'); ?>