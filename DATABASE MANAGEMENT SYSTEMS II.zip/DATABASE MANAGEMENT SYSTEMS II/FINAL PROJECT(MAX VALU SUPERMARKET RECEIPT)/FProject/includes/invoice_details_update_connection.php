<?php include ('header.php'); ?>
<?php include ("config.php");

// Sent from editmember_form.php by Method post , receive with $_POST
$Transaction_ID = $_POST['id'];
$Item_ID = trim($_POST['Item_ID']);
$Seliing_Quantity = trim($_POST['Seliing_Quantity']);


$sql = "UPDATE invoice_details SET Transaction_ID = '{$Transaction_ID}', Item_ID = '{$Item_ID}', Seliing_Quantity = '{$Seliing_Quantity}' WHERE Item_ID = '{$Item_ID}'";
?>


<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Invoice Details</li>
        </ol>

        <!-- DataTables Employees -->
        <div class="card mb-3">
            <div class="card-header clearfix">
                <h2>Update Invoice Details</h2>
            </div>
                    <table>
                     <tr>
                        <td style="text-align: center;">
                        <?php
                        // If member's data is updated successfully, show information and redirect to index.php
                        if($link->query($sql) == TRUE){
                            echo "<div id='message'>Record updated successfully <hr/>Please wait to redirect...</div>";
                            echo "<meta http-equiv='refresh' content='5;url=../invoice_details.php'>"; // Redirect to index.php
                        } else {
                            echo "<div id='message'>Error: " . $sql . "<br>" . $link->error ."<hr/>Please wait to redirect...</div>";
                            echo "<meta http-equiv='refresh' content='5;url=../invoice_details.php'>"; // Redirect to index.php
                        }
                        ?>
                        </td>
                    </tr>
                </table>
            </div>
        <?php $link->close(); ?>
    </div>
</div>
<?php include ('footer.php'); ?>