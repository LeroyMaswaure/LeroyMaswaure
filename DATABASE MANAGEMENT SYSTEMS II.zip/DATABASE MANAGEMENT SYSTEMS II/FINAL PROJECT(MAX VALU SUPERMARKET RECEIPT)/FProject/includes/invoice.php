<?php
class Invoice{
	private $host  = 'localhost';
    private $user  = 'root';
    private $password   = "";
    private $database  = "FProject";   
    private $invoiceOrderTable = 'invoice';
	private $invoiceOrderItemTable = 'invoice_details';
	private $dbConnect = false;
    public function __construct(){
        if(!$this->dbConnect){ 
            $link = new mysqli($this->host, $this->user, $this->password, $this->database);
            if($link->connect_error){
                die("Error failed to connect to MySQL: " . $link->connect_error);
            }else{
                $this->dbConnect = $link;
            }
        }
    }
	private function getData($sqlQuery) {
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		if(!$result){
			die('Error in query: '. mysqli_error());
		}
		$data= array();
		while ($row = mysqli_fetch_array($result, MYSQL_ASSOC)) {
			$data[]=$row;            
		}
		return $data;
	}
	private function getNumRows($sqlQuery) {
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		if(!$result){
			die('Error in query: '. mysqli_error());
		}
		$numRows = mysqli_num_rows($result);
		return $numRows;
	}
		
	public function saveInvoice($POST) {		
		$sqlInsert = "
			INSERT INTO ".$this->invoiceOrderTable."(Transaction_ID, Transaction_Date_Time, POS_ID, Cashier_ID, Customer_ID, Payment_Type, order_total_before_tax, order_total_tax, order_tax_per, order_total_after_tax, order_amount_paid, order_total_amount_due) 
			VALUES ('".$POST['Transaction_ID']."', '".$POST['Transaction_Date_Time']."', '".$POST['POS_ID']."', '".$POST['Cashier_ID']."', '".$POST['Customer_ID']."', '".$POST['Payment_Type']."', '".$POST['subTotal']."', '".$POST['taxAmount']."', '".$POST['taxRate']."', '".$POST['totalAftertax']."', '".$POST['amountPaid']."', '".$POST['amountDue']."')";

		mysqli_query($this->dbConnect, $sqlInsert);
		$lastInsertId = mysqli_insert_id($this->dbConnect);
		for ($i = 0; $i < count($POST['productCode']); $i++) {
			$sqlInsertItem = "
			INSERT INTO ".$this->invoiceOrderItemTable."(Transaction_ID, Item_ID, order_item_quantity, order_item_price, order_item_final_amount) 
			VALUES ('".$lastInsertId."', '".$POST['productCode'][$i]."', '".$POST['quantity'][$i]."', '".$POST['price'][$i]."', '".$POST['total'][$i]."')";			
			mysqli_query($this->dbConnect, $sqlInsertItem);
		}       	
	}	
	public function updateInvoice($POST) {
		if($POST['Transaction_ID']) {	
			$sqlInsert = "
				UPDATE ".$this->invoiceOrderTable." 
				SET Transaction_ID = '".$POST['Transaction_ID']."', Transaction_Date_Time = '".$POST['Transaction_Date_Time']."', POS_ID= '".$POST['POS_ID']."', Cashier_ID= '".$POST['Cashier_ID']."', Customer_ID= '".$POST['Customer_ID']."', Payment_Type= '".$POST['Payment_Type']."', order_total_before_tax = '".$POST['subTotal']."', order_total_tax = '".$POST['taxAmount']."', order_tax_per = '".$POST['taxRate']."', order_total_after_tax = '".$POST['totalAftertax']."', order_amount_paid = '".$POST['amountPaid']."', order_total_amount_due = '".$POST['amountDue']."', note = '".$POST['notes']."' 
				WHERE Cashier_ID = '".$POST['Cashier_ID']."' AND Transaction_ID = '".$POST['Transaction_ID']."'";		
			mysqli_query($this->dbConnect, $sqlInsert);	
		}		
		$this->deleteInvoiceItems($POST['Transaction_ID']);
		for ($i = 0; $i < count($POST['productCode']); $i++) {			
			$sqlInsertItem = "
				INSERT INTO ".$this->invoiceOrderItemTable."(Transaction_ID, Item_ID, order_item_quantity, order_item_price, order_item_final_amount) 
				VALUES ('".$POST['Transaction_ID']."', '".$POST['productCode'][$i]."', '".$POST['quantity'][$i]."', '".$POST['price'][$i]."', '".$POST['total'][$i]."')";			
			mysqli_query($this->dbConnect, $sqlInsertItem);			
		}       	
	}	
	public function getInvoiceList(){
		$sqlQuery = "
			SELECT * FROM ".$this->invoiceOrderTable." 
			WHERE Cashier_ID = '".$_SESSION['Cashier_ID']."'";
		return  $this->getData($sqlQuery);
	}	
	public function getInvoice($Transaction_ID){
		$sqlQuery = "
			SELECT * FROM ".$this->invoiceOrderTable." 
			WHERE Cashier_ID = '".$_SESSION['Cashier_ID']."' AND Transaction_ID = '$Transaction_ID'";
		$result = mysqli_query($this->dbConnect, $sqlQuery);	
		$row = mysqli_fetch_array($result, MYSQL_ASSOC);
		return $row;
	}	
	public function getInvoiceItems($Transaction_ID){
		$sqlQuery = "
			SELECT * FROM ".$this->invoiceOrderItemTable." 
			WHERE Transaction_ID = '$Transaction_ID'";
		return  $this->getData($sqlQuery);	
	}
	public function deleteInvoiceItems($Transaction_ID){
		$sqlQuery = "
			DELETE FROM ".$this->invoiceOrderItemTable." 
			WHERE Transaction_ID = '".$Transaction_ID."'";
		mysqli_query($this->dbConnect, $sqlQuery);				
	}
	public function deleteInvoice($Transaction_ID){
		$sqlQuery = "
			DELETE FROM ".$this->invoiceOrderTable." 
			WHERE Transaction_ID = '".$Transaction_ID."'";
		mysqli_query($this->dbConnect, $sqlQuery);	
		$this->deleteInvoiceItems($Transaction_ID);	
		return 1;
	}
}
?>