<?php include ("config.php");

$Item_ID = trim($_GET['id']); // Sent id by method GET , receive with $_GET

$sql = "DELETE FROM items WHERE Item_ID ='{$Item_ID}'";

?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Dashboard - Max Value Supermarket</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body>
<div id="content-wrapper">
    <div class="container-fluid">
            <div class="card-body" style="text-align: center;">
                        <?php
                        // If data is deleted successfully , show information and redirect to product.php
                        if($link->query($sql) == TRUE){
                            echo "<div id='message'>Record deleted successfully!</div>";
                            echo "<meta http-equiv='refresh' content='1;url=../products.php'>"; // Redirect to products.php
                        } else {
                            echo "<div id='message'>Error: " . $sql . "<br>" . $link->error ."</div>";
                            echo "<meta http-equiv='refresh' content='1;url=../products.php'>"; // Redirect to products.php
                        }
                        ?>
            </div>
    </div>
        <?php $link->close(); ?>
</div>
</body>