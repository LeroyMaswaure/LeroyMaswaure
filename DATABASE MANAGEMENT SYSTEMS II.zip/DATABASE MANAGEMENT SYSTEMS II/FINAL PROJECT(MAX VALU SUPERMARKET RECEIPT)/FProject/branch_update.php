<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

$Branch_ID = $_GET['id']; // Receive id from index.php by $_GET

// Data Query by id
$sql = "SELECT * FROM branch WHERE Branch_ID ='{$Branch_ID}'";
$result = $link->query($sql);
$row = $result->fetch_assoc();

?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Branch</li>
        </ol>

        <!-- DataTables Employees -->
        <div class="card mb-3">
            <div class="card-header clearfix">
                <h2>Update Branch</h2>
                <a href="branch.php" class="btn btn-info"; style="margin-left: 92%;">Return To List</a>
            </div>

            <div class="card-body">
               <tr>
                    <td>
                        <form name="update_branch" method="post" action="includes/branch_update_connection.php">
                            <table width="100%" cellspacing="5" cellpadding="5" class="table table-borderless">
                                 <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Branch Name:</td>
                                    <td><input type="text" name="Branch_Name" style="width: 250px; height: 30px;" value="<?php echo $row['Branch_Name'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Branch Address:</td>
                                    <td><input type="text" name="Branch_Address" style="width: 250px; height: 30px;" value="<?php echo $row['Branch_Address'];?>"/></td>
                                </tr>  

                                <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Branch City:</td>
                                    <td><input type="text" name="Branch_City" style="width: 250px; height: 30px;" value="<?php echo $row['Branch_City'];?>"/></td>
                                </tr>                                 

                                <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Branch Phone:</td>
                                    <td><input type="text" name="Branch_Phone" style="width: 250px; height: 30px;" value="<?php echo $row['Branch_Phone'];?>"/></td>
                                </tr>
                            </table>   

                               <tr>
                                    <td style="width: 120px; text-align: right;"></td>

                                    <td>
                                        <input type="hidden" name="id" value="<?php echo $row['Branch_ID'];?>" /><!-- Send id of update record -->
                                        <input type="submit" name="submit" value="Submit" class="btn btn-dark btn-lg" style="margin-left: 160px;" onclick="return confirm('Do you want to submit?')"/> 
                                    </td>
                                </tr>
                        </form>
                    </td>
                </tr>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>