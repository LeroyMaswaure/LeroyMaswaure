<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

$sql = "SELECT * FROM tbllogactivity"; // Assign SQL Statement to variable $sql
$result = $link->query($sql);
// Use query() function with $sql , variable $conn comes from connection.php
// Outcome from query() is assigned to variable $result

?>

<div id="content-wrapper">
	<div class="container-fluid">
		<!-- Breadcrumbs-->
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="#">Dashboard</a>
			</li>
			<li class="breadcrumb-item active">Activity Log</li>
		</ol>

		<!-- DataTables Employees -->
		<div class="mb-3">
			<div class="card-header clearfix">
				<h2 class="pull-left">Activity Log Details</h2>
			</div>

					<table width="100%" cellspacing="5" cellpadding="5" class="table table-hover table-bordered">
						<tr style="text-align: center;">
							<th>Log Date Time</th>
							<th>Log Activity</th>							
							<th>Log Table Name</th>
							<th>Log Detail</th>
							<th>Log User</th>
						</tr>

						<?php
                                    while($row = $result->fetch_assoc()){ // Loop While สำหรับดึงข้อมูลจากฐานข้อมูล โดยใช้ Function fetch_assoc()
                                    	?>
                                    	<!-- // Show the reault of Query via variable $row by echo command -->
                                    	<tr style="text-align: center;">
                                    		<td><?php echo $row['logDateTime'];?></td>
                                    		<td><?php echo $row['logActivity'];?></td>     	
                                    		<td><?php echo $row['logTableName'];?></td>
                                    		<td><?php echo $row['logDetail'];?></td>
                                    		<td><?php echo $row['logUser'];?></td>
                                    	</tr>
                                    	<?php
                                }                               
                                ?>
                            </table>
                        </td>
                    </tr>
                </div>
                <?php
$link->close();// ปิด Connection

?>
</div>
<!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>