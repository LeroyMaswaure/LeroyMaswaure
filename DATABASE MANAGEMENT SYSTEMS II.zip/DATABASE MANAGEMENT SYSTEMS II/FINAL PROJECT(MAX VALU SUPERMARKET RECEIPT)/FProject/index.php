<?php
session_start();
$message="";
if(count($_POST)>0) {
	include_once 'includes/config.php';
	$result = mysqli_query($conn,"SELECT * FROM cashier WHERE (userid='" . $_POST["Cashier_ID"] . "' or Username='" . $_POST["Username"] . "') and password = '". $_POST["Password"]."'");
	$row = mysqli_fetch_array($result);
	if(is_array($row)) {
		$_SESSION["userid"] = $row[userid];


	} else {
		$message = "Invalid username or Password!";
	}

}
if(isset($_SESSION["userid"])) {
	echo "Success";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>Dashboard Admin - Login</title>

	<!-- Custom fonts for this template-->
	<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

	<!-- Custom styles for this template-->
	<link href="css/sb-admin.css" rel="stylesheet">

</head>

<body class="bg-dark" style="margin-top: 250px;">

	<div class="container">
		<div class="title" style="text-align: center; color: white; font-weight: bold;">
			<h1>Max Value Supermarket Management</h1>
		</div>
		<div class="card card-login mx-auto mt-5">
			<div class="card-header">Login</div>
			<div class="card-body">
				<form method="post" action="dashboard.php" align="center">
					<div class="message"><?php if($message!="") { echo $message; } ?></div>
					<div class="form-group">
						<div class="form-label-group">
							<input type="Username" id="inputUsername" class="form-control" placeholder="Username" required="required" autofocus="autofocus">
							<label for="inputUsername">Username</label>
						</div>
					</div>
					<div class="form-group">
						<div class="form-label-group">
							<input type="password" id="inputPassword" class="form-control" placeholder="Password" required="required">
							<label for="inputPassword">Password</label>
						</div>
					</div>
				</br>
				<a class="btn btn-primary btn-lg btn-block" href="dashboard.php">Login</a>
			</form>
		</div>
	</div>
</div>

<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

</body>

</html>
