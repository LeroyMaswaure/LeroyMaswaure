<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

$Cashier_ID = $_GET['id']; // Receive id from index.php by $_GET

// Data Query by id
$sql = "SELECT * FROM cashier WHERE Cashier_ID ='{$Cashier_ID}'";
$result = $link->query($sql);
$row = $result->fetch_assoc();


?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Cashiers</li>
        </ol>

        <!-- DataTables Employees -->
        <div class="card mb-3">
            <div class="card-header clearfix">
                <h2>Update Cashier</h2>
                <a href="cashier.php" class="btn btn-info"; style="margin-left: 92%;">Return To List</a>
            </div>

            <div class="card-body">
               <tr>
                    <td>
                        <form name="update_cashier" method="post" action="includes/cashier_update_connection.php">
                            <table width="100%" cellspacing="5" cellpadding="5" class="table table-borderless">
                                <tr>
                                    <td style="width: 120px; text-align: right; font-weight: bold;">First Name:</td>
                                    <td><input type="text" name="FName" style="width: 250px; height: 30px;" value="<?php echo $row['FName'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 120px; text-align: right; font-weight: bold;">Middle Name:</td>
                                    <td><input type="text" name="M_Name" style="width: 250px; height: 30px;" value="<?php echo $row['M_Name'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 120px; text-align: right; font-weight: bold;">Last Name:</td>
                                    <td><input type="text" name="L_Name" style="width: 250px; height: 30px;" value="<?php echo $row['L_Name'];?>"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 120px; text-align: right; font-weight: bold;">Username:</td>
                                    <td><input type="text" name="Username" style="width: 250px; height: 30px;" value="<?php echo $row['Username'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 120px; text-align: right; font-weight: bold;">Password :</td>
                                    <td><input type="password" name="Password" style="width: 250px; height: 30px;" maxlength="8" value="<?php echo $row['Password'];?>"/></td>
                                </tr>
                              
                            </table>   

                               <tr>
                                    <td style="width: 120px; text-align: right;"></td>

                                    <td>
                                        <input type="hidden" name="id" value="<?php echo $row['Cashier_ID'];?>" /><!-- Send id of update record -->
                                        <input type="submit" name="submit" value="Submit" class="btn btn-dark btn-lg" style="margin-left: 130px;" onclick="return confirm('Do you want to submit?')"/> 
                                    </td>
                                </tr>
                        </form>
                    </td>
                </tr>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>