<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

$sql = "SELECT * FROM customers"; // Assign SQL Statement to variable $sql
$result = $link->query($sql);
// Use query() function with $sql , variable $conn comes from connection.php
// Outcome from query() is assigned to variable $result

?>

<div id="content-wrapper">
	<div class="container-fluid">
		<!-- Breadcrumbs-->
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="#">Dashboard</a>
			</li>
			<li class="breadcrumb-item active">Customers</li>
		</ol>

		<!-- DataTables Employees -->
		<div class="mb-3">
			<div class="card-header clearfix">
				<h2 class="pull-left">Customers Details</h2>
				<a href="customers_create.php" class="btn btn-primary pulll-right"; style="margin-left: 89%;">Add New Customer</a>
			</div>

			<tr>
				<td>
					<table width="100%" cellspacing="5" cellpadding="5" class="table table-hover table-bordered">
						<tr style="text-align: center;">
							<th>Customer ID</th>
							<th>First Name</th>
							<th>Middel Name</th>
							<th>Last Name</th>
							<th>Member Registration Date</th>							
							<th>Action</th>
						</tr>

						<?php
                                // If it has data in memebers table, show the data.
						if ($result->num_rows > 0) {
							$i = 1;
                                    while($row = $result->fetch_assoc()){ // Loop While สำหรับดึงข้อมูลจากฐานข้อมูล โดยใช้ Function fetch_assoc()
                                    	?>
                                    	<!-- // Show the reault of Query via variable $row by echo command -->
                                    	<tr style="text-align: center;">
                                    		<td><?php echo $row['Customer_ID'];?></td>
                                    		<td><?php echo $row['Customer_FName'];?></td>
                                    		<td><?php echo $row['Customer_MName'];?></td>
                                    		<td><?php echo $row['Customer_LName'];?></td>
                                    		<td><?php echo $row['Member_registration_date'];?></td>
                                    		<td>
                                    			<!–- Link for Update and Delete -->
                                    			<a href="customers_update.php?id=<?php echo $row['Customer_ID'];?>" class="btn btn-warning">Update</a>&nbsp;
                                    			<a href="includes/customers_delete_connection.php?id=<?php echo $row['Customer_ID'];?>" class="btn btn-danger">Delete</a>
                                    		</td>
                                    	</tr>
                                    	<?php
                                    	$i++;
                                    }
                                }                               
                                ?>
                            </table>
                        </td>
                    </tr>
                </div>
                <?php
$link->close();// ปิด Connection

?>
</div>
<!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>