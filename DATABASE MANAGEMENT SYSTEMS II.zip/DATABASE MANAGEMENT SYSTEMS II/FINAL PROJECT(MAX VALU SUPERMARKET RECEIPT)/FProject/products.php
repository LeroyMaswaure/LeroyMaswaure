<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

$limit = 5;  
if (isset($_GET["page"])) {
	$page  = $_GET["page"]; 
	} 
	else{ 
	$page=1;
	};  
$start_from = ($page-1) * $limit;  
$sql = "SELECT * FROM View_items"; // Assign SQL Statement to variable $sql
$result = $link->query($sql);
?>
    	<div id="content-wrapper">
    		<div class="container-fluid">
    			<!-- Breadcrumbs-->
    			<ol class="breadcrumb">
    				<li class="breadcrumb-item">
    					<a href="#">Dashboard</a>
    				</li>
    				<li class="breadcrumb-item active">Products</li>
    			</ol>

    			<!-- DataTables Employees -->
    			<div class="mb-3">
    				<div class="card-header clearfix">
    					<h2 class="pull-left">Products Details</h2>
    					<a href="products_create.php" class="btn btn-primary pulll-right"; style="margin-left: 89%;">Add New Product</a>
    				</div>

    				<tr>
    					<td>
    						<table width="100%" cellspacing="5" cellpadding="5" class="table table-hover table-bordered">
    							<tr style="text-align: center;">
    								<th>Item ID</th>
                                    <th>Item Name</th>
    								<th>Sub Category Name</th>
    								<th>Unit Price</th>
    								<th>Quantity in Stock</th>
    								<th>Action</th>
    							</tr>

    							<?php  
    							while ($row = mysqli_fetch_array($result)) {  
    								?> 
    								<!-- // Show the reault of Query via variable $row by echo command -->
    								<tr style="text-align: center;">
    									<td><?php echo $row['Item_ID'];?></td>
    									<td><?php echo $row['Item_Name'];?></td>
    									<td><?php echo $row['Sub_Category_Name'];?></td>
    									<td><?php echo $row['Unit_Price'];?></td>
    									<td><?php echo $row['Quantity'];?></td>
    									<td>
    										<!–- Link for Update and Delete -->
    										<a href="products_update.php?id=<?php echo $row['Item_ID'];?>" class="btn btn-warning">Update</a>&nbsp;
    										<a href="includes/products_delete_connection.php?id=<?php echo $row['Item_ID'];?>" class="btn btn-danger">Delete</a>
    									</td>
    								</tr>
    								<?php  
    							};  
    							?>
    						</table>
    						<?php  
    						$result_db = mysqli_query($link,"SELECT COUNT(Item_ID) FROM items"); 
    						$row_db = mysqli_fetch_row($result_db);  
    						$total_records = $row_db[0];  
    						$total_pages = ceil($total_records / $limit); 
    						/* echo  $total_pages; */
    						$pagLink = "<ul class='pagination'>";  
    						for ($i=1; $i<=$total_pages; $i++) {
    							$pagLink .= "<li class='page-item'><a class='page-link' href='products.php?page=".$i."'>".$i."</a></li>";	
    						}
    						echo $pagLink . "</ul>";  
    						?>
    					</td>
    				</tr>
    			</div>
    			<?php
$link->close();// ปิด Connection

?>
</div>
<!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>