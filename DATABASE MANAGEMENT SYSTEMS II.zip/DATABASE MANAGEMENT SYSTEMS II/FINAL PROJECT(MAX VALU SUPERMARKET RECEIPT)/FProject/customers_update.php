<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

$Customer_ID = $_GET['id']; // Receive id from index.php by $_GET

// Data Query by id
$sql = "SELECT * FROM customers WHERE Customer_ID ='{$Customer_ID}'";
$result = $link->query($sql);
$row = $result->fetch_assoc();


?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Customers</li>
        </ol>

        <!-- DataTables Employees -->
        <div class="card mb-3">
            <div class="card-header clearfix">
                <h2>Update Customer</h2>
                <a href="customers.php" class="btn btn-info"; style="margin-left: 92%;">Return To List</a>
            </div>

            <div class="card-body">
                <div class="table-responsive">
               <tr>
                    <td>
                        <form name="update_customers" method="post" action="includes/customers_update_connection.php">
                            <table width="100%" cellspacing="5" cellpadding="5" class="table table-borderless">
                                 <tr>
                                    <td style="width: 250px; text-align: right; font-weight: bold;">First Name:</td>
                                    <td><input type="text" name="Customer_FName" style="width: 250px; height: 30px;" value="<?php echo $row['Customer_FName'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 250px; text-align: right; font-weight: bold;">Middle Name:</td>
                                    <td><input type="text" name="Customer_MName" style="width: 250px; height: 30px;" value="<?php echo $row['Customer_MName'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 250px; text-align: right; font-weight: bold;">Last Name:</td>
                                    <td><input type="text" name="Customer_LName" style="width: 250px; height: 30px;" value="<?php echo $row['Customer_LName'];?>"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 250px; text-align: right; font-weight: bold;">Member Registration Date:</td>
                                    <td><input type="text" name="Member_registration_date" style="width: 250px; height: 30px;" value="<?php echo $row['Member_registration_date'];?>"/></td>
                                </tr>    
                            </table>   

                               <tr>
                                    <td style="width: 120px; text-align: right;"></td>

                                    <td>
                                        <input type="hidden" name="id" value="<?php echo $row['Customer_ID'];?>" /><!-- Send id of update record -->
                                        <input type="submit" name="submit" value="Submit" class="btn btn-dark btn-lg" style="margin-left: 260px;" onclick="return confirm('Do you want to submit?')"/> 
                                    </td>
                                </tr>
                        </form>
                    </td>
                </tr>

                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>