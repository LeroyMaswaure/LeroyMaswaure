<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

?>

<div id="content-wrapper">
	<div class="container-fluid">
		<!-- Breadcrumbs-->
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="#">Dashboard</a>
			</li>
			<li class="breadcrumb-item active">Invoice</li>
		</ol>

		<!-- DataTables Employees -->
		<div class="card mb-3">
			<div class="card-header clearfix">
				<h2>Add New Invoice</h2>
				<a href="invoice.php" class="btn btn-info"; style="margin-left: 92%;">Return To List</a>
			</div>

			<div class="card-body">
				<div class="table-responsive">
               <tr>
                    <td>
                        <form name="create_invoice" method="post" action="includes/invoice_create_connection.php">
                            <table width="100%" cellspacing="5" cellpadding="5" class="table table-borderless">
                                 <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Transaction ID:</td>
                                    <td><input type="text" name="Transaction_ID" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Transaction Date:</td>
                                    <td><input type="text" name="Transaction_Date" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Transaction Time:</td>
                                    <td><input type="text" name="Transaction_time" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Terminal ID:</td>
                                    <td><input type="text" name="Terminal_ID" style="width: 250px; height: 30px;"/></td>
                                </tr>


                                 <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Cashier ID:</td>
                                    <td><input type="text" name="Cashier_ID" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Customer ID:</td>
                                    <td><input type="text" name="Customer_ID" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Customer Earn Point:</td>
                                    <td><input type="text" name="Customer_EarnPoint" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Payment Type:</td>
                                    <td><input type="text" name="Payment_Type" style="width: 250px; height: 30px;"/></td>
                                </tr>                                                                                                
                            </table>   

                               <tr>
                                    <td style="width: 120px; text-align: right;"></td>
                                    <td>
                                        <input type="hidden" name="id" value="<?php echo $row['Transaction_ID'];?>" /><!-- Send id of update record -->
                                        <input type="submit" name="submit" value="Submit" class="btn btn-dark btn-lg" style="margin-left: 130px;" onclick="return confirm('Do you want to submit?')"/> 
                                    </td>
                                </tr>
                        </form>
                    </td>
                </tr>

				</div>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
    <?php 

$sql = "SELECT * FROM cashier"; // Assign SQL Statement to variable $sql
$result = $link->query($sql);
// Use query() function with $sql , variable $conn comes from connection.php
// Outcome from query() is assigned to variable $result

?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item active">Cashiers</li>
        </ol>

        <!-- DataTables Employees -->
        <div class="mb-3">
            <div class="card-header clearfix">
                <h2 class="pull-left">Cashiers Details</h2>
            </div>

            <tr>
                <td>
                    <table width="100%" cellspacing="5" cellpadding="5" class="table table-hover table-bordered">
                        <tr style="text-align: center;">
                            <th>Cashier ID</th>
                            <th>First Name</th>
                            <th>Middle Name</th>
                            <th>Last Name</th>                          
                            
                        </tr>

                        <?php
                                // If it has data in memebers table, show the data.
                        if ($result->num_rows > 0) {
                            $i = 1;
                                    while($row = $result->fetch_assoc()){ // Loop While สำหรับดึงข้อมูลจากฐานข้อมูล โดยใช้ Function fetch_assoc()
                                        ?>
                                        <!-- // Show the reault of Query via variable $row by echo command -->
                                        <tr style="text-align: center;">
                                            <td><?php echo $row['Cashier_ID'];?></td>
                                            <td><?php echo $row['FName'];?></td>
                                            <td><?php echo $row['M_Name'];?></td>
                                            <td><?php echo $row['L_Name'];?></td>       
                                        </tr>
                                        <?php
                                        $i++;
                                    }
                                }                               
                                ?>

                            </table>
                            <?php 
$sql = "SELECT * FROM customers"; // Assign SQL Statement to variable $sql
$result = $link->query($sql);
// Use query() function with $sql , variable $conn comes from connection.php
// Outcome from query() is assigned to variable $result

?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item active">Customers</li>
        </ol>

        <!-- DataTables Employees -->
        <div class="mb-3">
            <div class="card-header clearfix">
                <h2 class="pull-left">Customers Details</h2>
            </div>

            <tr>
                <td>
                    <table width="100%" cellspacing="5" cellpadding="5" class="table table-hover table-bordered">
                        <tr style="text-align: center;">
                            <th>Customer ID</th>
                            <th>First Name</th>
                            <th>Middel Name</th>
                            <th>Last Name</th>                         
                        </tr>

                        <?php
                                // If it has data in memebers table, show the data.
                        if ($result->num_rows > 0) {
                            $i = 1;
                                    while($row = $result->fetch_assoc()){ // Loop While สำหรับดึงข้อมูลจากฐานข้อมูล โดยใช้ Function fetch_assoc()
                                        ?>
                                        <!-- // Show the reault of Query via variable $row by echo command -->
                                        <tr style="text-align: center;">
                                            <td><?php echo $row['Customer_ID'];?></td>
                                            <td><?php echo $row['Customer_FName'];?></td>
                                            <td><?php echo $row['Customer_MName'];?></td>
                                            <td><?php echo $row['Customer_LName'];?></td>
                                        </tr>
                                        <?php
                                        $i++;
                                    }
                                }                               
                                ?>
                            </table>
                        </td>
                    </tr>
                </div>

                        </td>
                    </tr>

                </div>

                
</div>

<?php include ('includes/footer.php'); ?>