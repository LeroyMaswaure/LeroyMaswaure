<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

$sql = "SELECT * FROM View_invoice_details"; // Assign SQL Statement to variable $sql
$result = $link->query($sql);
// Use query() function with $sql , variable $conn comes from connection.php
// Outcome from query() is assigned to variable $result

?>

<div id="content-wrapper">
	<div class="container-fluid">
		<!-- Breadcrumbs-->
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="#">Dashboard</a>
			</li>
			<li class="breadcrumb-item active">Invoice Details</li>
		</ol>

		<!-- DataTables Employees -->
		<div class="mb-3">
			<div class="card-header clearfix">
				<h2 class="pull-left">Invoice Details</h2>
				<!-- <a href="invoice_details_create.php" class="btn btn-primary pulll-right"; style="margin-left: 87%;">Add New Invoice Details</a> -->
			</div>

			<tr>
				<td>
					<table width="100%" cellspacing="5" cellpadding="5" class="table table-hover table-bordered">
						<tr style="text-align: center;">
							<th>Transaction ID</th>
							<th>Item Name</th>
							<th>VAT Percentage</th>
							<th>Quantity</th>
							<th>Unit Price</th>
							<th>Total Price</th>
							
						</tr>

						<?php
                                // If it has data in memebers table, show the data.
						if ($result->num_rows > 0) {
							$i = 1;
                                    while($row = $result->fetch_assoc()){ // Loop While สำหรับดึงข้อมูลจากฐานข้อมูล โดยใช้ Function fetch_assoc()
                                    	?>
                                    	<!-- // Show the reault of Query via variable $row by echo command -->
                                    	<tr style="text-align: center;">
                                    		<td><?php echo $row['Transaction_ID'];?></td>
                                    		<td><?php echo $row['Item_Name'];?></td>
                                    		<td><?php echo $row['Percentage'];?></td>
                                    		<td><?php echo $row['order_item_quantity'];?></td>
                                    		<td><?php echo $row['order_item_price'];?></td>
                                    		<td><?php echo $row['Name_exp_6'];?></td>
                                    		
                                    	</tr>
                                    	<?php
                                    	$i++;
                                    }
                                }                               
                                ?>
                            </table>
                        </td>
                    </tr>
                </div>
                <?php
$link->close();// ปิด Connection

?>
</div>
<!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>