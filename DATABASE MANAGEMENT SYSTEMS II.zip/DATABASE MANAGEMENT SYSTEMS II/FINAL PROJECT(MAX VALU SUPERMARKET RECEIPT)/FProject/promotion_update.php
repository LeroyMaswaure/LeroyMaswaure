<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

$Discount_ID = $_GET['id']; // Receive id from index.php by $_GET

// Data Query by id
$sql = "SELECT * FROM promotion WHERE Discount_ID ='{$Discount_ID}'";
$result = $link->query($sql);
$row = $result->fetch_assoc();


?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Promotion</li>
        </ol>

        <!-- DataTables Employees -->
        <div class="card mb-3">
            <div class="card-header clearfix">
                <h2>Update Promotion</h2>
                <a href="promotion.php" class="btn btn-info"; style="margin-left: 92%;">Return To List</a>
            </div>

            <div class="card-body">
                <div class="table-responsive">
               <tr>
                    <td>
                        <form name="update_promotion" method="post" action="includes/promotion_update_connection.php">
                            <table width="100%" cellspacing="5" cellpadding="5" class="table table-borderless">
                                 <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">Item ID:</td>
                                    <td><input type="text" name="Item_ID" style="width: 250px; height: 30px;" value="<?php echo $row['Item_ID'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">Start Date:</td>
                                    <td><input type="text" name="Start_Date" style="width: 250px; height: 30px;" value="<?php echo $row['Start_Date'];?>"/></td>
                                </tr>                              

                                <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">End Date:</td>
                                    <td><input type="text" name="End_Date" style="width: 250px; height: 30px;" value="<?php echo $row['End_Date'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">Discount Type:</td>
                                    <td>
                                        <select name="Discount_Type" style="height: 30px; width: 250px;">
                                            <option value="Normal Discount" <?php if($row['Discount_Type'] == 'Normal Discount'){ echo "selected";}?>>Normal Discount</option>
                                            <option value="AEON Discount" <?php if($row['Discount_Type'] == 'AEON Discount'){ echo "selected";}?>>AEON Discount</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">Amount_Discount:</td>
                                    <td><input type="text" name="Amount" style="width: 250px; height: 30px;" value="<?php echo $row['Amount'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">Coupon Code:</td>
                                    <td><input type="text" name="Coupon_Code" style="width: 250px; height: 30px;" value="<?php echo $row['Coupon_Code'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">Status:</td>
                                    <td>
                                        <select name="Status" style="height: 30px; width: 250px;">
                                            <option value="Active" <?php if($row['Status'] == 'Active'){ echo "selected";}?>>Active</option>
                                            <option value="Inactive" <?php if($row['Status'] == 'Inactive'){ echo "selected";}?>>Inactive</option>
                                        </select>
                                    </td>
                                </tr>
                            </table>   

                               <tr>
                                    <td style="width: 120px; text-align: right;"></td>

                                    <td>
                                        <input type="hidden" name="id" value="<?php echo $row['Discount_ID'];?>" /><!-- Send id of update record -->
                                        <input type="submit" name="submit" value="Submit" class="btn btn-dark btn-lg" style="margin-left: 210px;" onclick="return confirm('Do you want to submit?')"/> 
                                    </td>
                                </tr>
                        </form>
                    </td>
                </tr>

                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>