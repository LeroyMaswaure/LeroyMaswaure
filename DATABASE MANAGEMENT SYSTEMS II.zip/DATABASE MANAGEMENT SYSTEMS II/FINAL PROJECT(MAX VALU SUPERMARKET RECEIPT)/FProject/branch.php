<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

$sql = "SELECT * FROM branch"; // Assign SQL Statement to variable $sql
$result = $link->query($sql);
// Use query() function with $sql , variable $conn comes from connection.php
// Outcome from query() is assigned to variable $result

?>

<div id="content-wrapper">
	<div class="container-fluid">
		<!-- Breadcrumbs-->
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="#">Dashboard</a>
			</li>
			<li class="breadcrumb-item active">Branch</li>
		</ol>

		<!-- DataTables Employees -->
		<div class="mb-3">
			<div class="card-header clearfix">
				<h2 class="pull-left">Branch Details</h2>
				<a href="branch_create.php" class="btn btn-primary pulll-right"; style="margin-left: 89%;">Add New Branch</a>
			</div>

			<tr>
				<td>
					<table width="100%" cellspacing="5" cellpadding="5" class="table table-hover table-bordered">
						<tr style="text-align: center;">
							<th>Branch ID</th>
							<th>Branch Name</th>
							<th>Branch Address</th>
							<th> Branch City</th>
							<th>Branch Phone</th>
							<th>Action</th>
						</tr>

						<?php
                                // If it has data in memebers table, show the data.
						if ($result->num_rows > 0) {
							$i = 1;
                                    while($row = $result->fetch_assoc()){ // Loop While สำหรับดึงข้อมูลจากฐานข้อมูล โดยใช้ Function fetch_assoc()
                                    	?>
                                    	<!-- // Show the reault of Query via variable $row by echo command -->
                                    	<tr style="text-align: center;">
                                    		<td><?php echo $row['Branch_ID'];?></td>
                                    		<td><?php echo $row['Branch_Name'];?></td>
                                    		<td><?php echo $row['Branch_Address'];?></td>
                                    		<td><?php echo $row['Branch_City'];?></td>
                                    		<td><?php echo $row['Branch_Phone'];?></td>
                                    		<td>
                                    			<!–- Link for Update and Delete -->
                                    			<a href="branch_update.php?id=<?php echo $row['Branch_ID'];?>" class="btn btn-warning">Update</a>&nbsp;
                                    			<a href="includes/branch_delete_connection.php?id=<?php echo $row['Branch_ID'];?>" class="btn btn-danger">Delete</a>
                                    		</td>
                                    	</tr>
                                    	<?php
                                    	$i++;
                                    }
                                }                               
                                ?>
                            </table>
                        </td>
                    </tr>
                </div>
                <?php
$link->close();// ปิด Connection

?>
</div>
<!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>