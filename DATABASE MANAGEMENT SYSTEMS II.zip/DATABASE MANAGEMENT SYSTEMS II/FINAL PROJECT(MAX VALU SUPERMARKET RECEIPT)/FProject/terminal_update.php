<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

$Terminal_ID = $_GET['id']; // Receive id from index.php by $_GET

// Data Query by id
$sql = "SELECT * FROM terminal WHERE Terminal_ID ='{$Terminal_ID}'";
$result = $link->query($sql);
$row = $result->fetch_assoc();


?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Terminals in PATTANAKARN Branch</li>
        </ol>

        <!-- DataTables Employees -->
        <div class="card mb-3">
            <div class="card-header clearfix">
                <h2>Update Terminal</h2>
                <a href="terminal.php" class="btn btn-info"; style="margin-left: 92%;">Return To List</a>
            </div>

            <div class="card-body">
               <tr>
                    <td>
                        <form name="update_terminal" method="post" action="includes/terminal_update_connection.php">
                            <table width="100%" cellspacing="5" cellpadding="5" class="table table-borderless">
                                 

                                 <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Terminal N°:</td>
                                    <td><input type="text" name="Terminal_Num" style="width: 250px; height: 30px;" value="<?php echo $row['Terminal_Num'];?>"/></td>
                                </tr>


                                <td style="width: 120px; text-align: right; font-weight: bold;">Pattanakarn Branch:</td>
                                    <td>
                                        <select name="Branch_ID" style="height: 30px;" value="<?php echo $row['Branch_ID'];?>">
                                            <option selected value="1">1</option>
                                        </select>
                                    </td>     

                            </table>   

                               <tr>
                                    <td style="width: 120px; text-align: right;"></td>

                                    <td>
                                        <input type="hidden" name="id" value="<?php echo $row['Terminal_ID'];?>" /><!-- Send id of update record -->
                                        <input type="submit" name="submit" value="Submit" class="btn btn-dark btn-lg" style="margin-left: 160px;" onclick="return confirm('Do you want to submit?')"/> 
                                    </td>
                                </tr>
                        </form>
                    </td>
                </tr>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>