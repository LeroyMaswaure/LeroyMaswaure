<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

?>

<div id="content-wrapper">
	<div class="container-fluid">
		<!-- Breadcrumbs-->
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="#">Dashboard</a>
			</li>
			<li class="breadcrumb-item active">Customers</li>
		</ol>

		<!-- DataTables Employees -->
		<div class="card mb-3">
			<div class="card-header clearfix">
				<h2>Add New Customer</h2>
				<a href="customers.php" class="btn btn-info"; style="margin-left: 92%;">Return To List</a>
			</div>

			<div class="card-body">
               <tr>
                    <td>
                        <form name="create_customers" method="post" action="includes/customers_create_connection.php">
                            <table width="100%" cellspacing="5" cellpadding="5" class="table  table-hover table-borderless">
                                 <tr>
                                    <td style="width: 250px; text-align: right; font-weight: bold;">First Name:</td>
                                    <td><input type="text" name="Customer_FName" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 250px; text-align: right; font-weight: bold;">Middel Name:</td>
                                    <td><input type="text" name="Customer_MName" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 250px; text-align: right; font-weight: bold;">Last Name:</td>
                                    <td><input type="text" name="Customer_LName" style="width: 250px; height: 30px;"/></td>
                                </tr>
                             
                                 <tr>
                                    <td style="width: 250px; text-align: right; font-weight: bold;">Member Registration Date:</td>
                                    <td><input type="text" name="Member_registration_date" style="width: 250px; height: 30px;"/></td>
                                </tr>

                            </table>   

                               <tr>
                                    <td style="width: 120px; text-align: right;"></td>
                                    <td>
                                     <input type="hidden" name="id" value="<?php echo $row['Customer_ID'];?>" /><!-- Send id of update record -->
                                        <input type="submit" name="submit" value="Submit" class="btn btn-dark btn-lg" style="margin-left: 260px;" onclick="return confirm('Do you want to submit?')"/> 
                                    </td>
                                </tr>
                        </form>
                    </td>
                </tr>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>