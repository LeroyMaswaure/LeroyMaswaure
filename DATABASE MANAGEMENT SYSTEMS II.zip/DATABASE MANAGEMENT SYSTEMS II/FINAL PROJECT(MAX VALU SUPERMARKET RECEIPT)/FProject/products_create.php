<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

?>

<div id="content-wrapper">
	<div class="container-fluid">
		<!-- Breadcrumbs-->
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="#">Dashboard</a>
			</li>
			<li class="breadcrumb-item active">Products</li>
		</ol>

		<!-- DataTables Employees -->
		<div class="card mb-3">
			<div class="card-header clearfix">
				<h2>Add New Products</h2>
				<a href="products.php" class="btn btn-info"; style="margin-left: 92%;">Return To List</a>
			</div>

			<div class="card-body">
				<div class="table-responsive">
               <tr>
                    <td>
                        <form name="create_products" method="post" action="includes/products_create_connection.php">
                            <table width="100%" cellspacing="5" cellpadding="5" class="table table-borderless">
                                <tr>
                                    <td style="width: 160px; text-align: right; font-weight: bold;">Sub Category ID:</td>
                                    <td><input type="text" name="Sub_Category_ID" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 160px; text-align: right; font-weight: bold;">Item Name:</td>
                                    <td><input type="text" name="Item_Name" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 160px; text-align: right; font-weight: bold;">Unit Price:</td>
                                    <td><input type="text" name="Unit_Price" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 160px; text-align: right; font-weight: bold;">Quantity:</td>
                                    <td><input type="text" name="Quantity" style="width: 250px; height: 30px;"/></td>
                                </tr>
                            </table>   

                               <tr>
                                    <td style="width: 120px; text-align: right;"></td>
                                    <td>
                                        <input type="hidden" name="id" value="<?php echo $row['Item_ID'];?>" /><!-- Send id of update record -->
                                        <input type="submit" name="submit" value="Submit" class="btn btn-dark btn-lg" style="margin-left: 130px;" onclick="return confirm('Do you want to submit?')"/> 
                                    </td>
                                </tr>
                        </form>
                    </td>
                </tr>

				</div>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
   <?php 

$limit = 5;  
if (isset($_GET["page"])) {
    $page  = $_GET["page"]; 
} 
else{ 
    $page=1;
};  
$start_from = ($page-1) * $limit;  
$sql = "SELECT * FROM View_items_sub_categories"; // Assign SQL Statement to variable $sql
$result = $link->query($sql);
?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Sub Category</li>
        </ol>

        <!-- DataTables Employees -->
        <div class="mb-3">
            <div class="card-header clearfix">
                <h2 class="pull-left">Sub Category Details</h2>
            </div>

            <tr>
                <td>
                    <table width="100%" cellspacing="5" cellpadding="5" class="table table-hover table-bordered">
                        <tr style="text-align: center;">
                            <th> Sub Category ID</th>
                            <th>sub Category Name</th>
                        </tr>

                        <?php  
                        while ($row = mysqli_fetch_array($result)) {  
                            ?> 
                            <!-- // Show the reault of Query via variable $row by echo command -->
                            <tr style="text-align: center;">
                                <td><?php echo $row['Sub_Category_ID'];?></td>
                                <td><?php echo $row['Sub_Category_Name'];?></td>
                            </tr>
                            <?php  
                        };  
                        ?>
                    
                </td>
            </tr>
        </div>
</div>

<?php include ('includes/footer.php'); ?>