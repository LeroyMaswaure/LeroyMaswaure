<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

$Transaction_ID = $_GET['id']; // Receive id from index.php by $_GET

// Data Query by id
$sql = "SELECT * FROM invoice WHERE Transaction_ID ='{$Transaction_ID}'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();


?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Invoice</li>
        </ol>

        <!-- DataTables Employees -->
        <div class="card mb-3">
            <div class="card-header clearfix">
                <h2>Update Invoice</h2>
                <a href="invoice.php" class="btn btn-info"; style="margin-left: 92%;">Return To List</a>
            </div>

            <div class="card-body">
                <div class="table-responsive">
               <tr>
                    <td>
                        <form name="update_invoice" method="post" action="includes/invoice_update_connection.php">
                            <table width="100%" cellspacing="5" cellpadding="5" class="table table-borderless">
                                 <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Transaction 
                                    ID:</td>
                                    <td><input type="text" name="Transaction_ID" style="width: 250px; height: 30px;" value="<?php echo $row['Transaction_ID'];?>"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Cashier ID:</td>
                                    <td><input type="text" name="Cashier_ID" style="width: 250px; height: 30px;" value="<?php echo $row['Cashier_ID'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Transaction Date Time:</td>
                                    <td><input type="text" name="Transaction_Date_Time" style="width: 250px; height: 30px;" value="<?php echo $row['Transaction_Date_Time'];?>"/></td>
                                </tr>                              

                                <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">POS ID:</td>
                                    <td><input type="text" name="POS_ID" style="width: 250px; height: 30px;" value="<?php echo $row['POS_ID'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Customer Scan:</td>
                                    <td><input type="text" name="Customer_Scan" style="width: 250px; height: 30px;" value="<?php echo $row['Customer_Scan'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Customer ID:</td>
                                    <td><input type="text" name="Customer_ID" style="width: 250px; height: 30px;" value="<?php echo $row['Customer_ID'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Customer Earn Point:</td>
                                    <td><input type="text" name="Customer_EarnPoint" style="width: 250px; height: 30px;" value="<?php echo $row['Customer_EarnPoint'];?>"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 150px; text-align: right; font-weight: bold;">Payment ID:</td>
                                    <td><input type="text" name="Payment_ID" style="width: 250px; height: 30px;" value="<?php echo $row['Payment_ID'];?>"/></td>
                                </tr>

                            </table>   

                               <tr>
                                    <td style="width: 120px; text-align: right;"></td>

                                    <td>
                                        <input type="hidden" name="id" value="<?php echo $row['Transaction_ID'];?>" /><!-- Send id of update record -->
                                        <input type="submit" name="submit" value="Submit" class="btn btn-dark btn-lg" style="margin-left: 130px;" onclick="return confirm('Do you want to submit?')"/> 
                                    </td>
                                </tr>
                        </form>
                    </td>
                </tr>

                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>