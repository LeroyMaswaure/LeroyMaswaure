<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

?>

<div id="content-wrapper">
	<div class="container-fluid">
		<!-- Breadcrumbs-->
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="#">Dashboard</a>
			</li>
			<li class="breadcrumb-item active">Promotion</li>
		</ol>

		<!-- DataTables Employees -->
		<div class="card mb-3">
			<div class="card-header clearfix">
				<h2>Add New Promotion</h2>
				<a href="promotion.php" class="btn btn-info"; style="margin-left: 92%;">Return To List</a>
			</div>

			<div class="card-body">
				<div class="table-responsive">
               <tr>
                    <td>
                        <form name="create_promotion" method="post" action="includes/promotion_create_connection.php">
                            <table width="100%" cellspacing="5" cellpadding="5" class="table table-borderless">
                                 <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">Item ID:</td>
                                    <td><input type="text" name="Item_ID" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">Start Date:</td>
                                    <td><input type="text" name="Start_Date" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">End Date:</td>
                                    <td><input type="text" name="End_Date" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">Discount Type:</td>
                                    <td>
                                        <select name="Discount_Type" style="height: 30px; width: 250px;">
                                            <option selected value="Normal Discount">Normal Discount</option>
                                            <option value="AEON Discount">AEON Discount</option>
                                        </select>
                                    </td>
                                </tr>

                                 <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">Amount in Percent:</td>
                                    <td><input type="text" name="Amount" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">Coupon Code:</td>
                                    <td><input type="text" name="Coupon_Code" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">Status:</td>
                                    <td>
                                        <select name="Status" style="height: 30px; width: 250px;">
                                            <option selected value="Active">Active</option>
                                            <option value="Inactive">Inactive</option>
                                        </select>
                                    </td>
                                </tr>
                            </table>   

                               <tr>
                                    <td style="width: 120px; text-align: right;"></td>
                                    <td>
                                        <input type="hidden" name="Discount_ID" value="<?php echo $row['Discount_ID'];?>" /><!-- Send id of Create record -->
                                    	<input type="submit" name="submit" value="Submit" class="btn btn-dark btn-lg" style="margin-left: 210px;" onclick="return confirm('Do you want to submit?')"/> 
                                    </td>
                                </tr>
                        </form>
                    </td>
                </tr>

				</div>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>