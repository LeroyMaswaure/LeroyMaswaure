<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

?>

<div id="content-wrapper">
	<div class="container-fluid">
		<!-- Breadcrumbs-->
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="#">Dashboard</a>
			</li>
			<li class="breadcrumb-item active">Sub Category</li>
		</ol>

		<!-- DataTables Employees -->
		<div class="card mb-3">
			<div class="card-header clearfix">
				<h2>Add New Sub Category</h2>
				<a href="sub_category.php" class="btn btn-info"; style="margin-left: 92%;">Return To List</a>
			</div>

			<div class="card-body">
				<div class="table-responsive">
               <tr>
                    <td>
                        <form name="sub_create_category" method="post" action="includes/sub_category_create_connection.php">
                            <table width="100%" cellspacing="5" cellpadding="5" class="table table-borderless">

                                 <tr>
                                    <td style="width: 230px; text-align: right; font-weight: bold;">Sub Category Name:</td>
                                    <td><input type="text" name="Sub_Category_Name" style="width: 250px; height: 30px;"/></td>
                                </tr>

                                 <tr>
                                    <td style="width: 230px; text-align: right; font-weight: bold;">Category ID:</td>
                                    <td><input type="text" name="Category_ID" style="width: 250px; height: 30px;"/></td>
                                </tr>
                             
                            </table>   

                               <tr>
                                    <td style="width: 230px; text-align: right;"></td>
                                    <td>
                                        <input type="hidden" name="Sub_Category_ID" value="<?php echo $row['Sub_Category_ID'];?>" /><!-- Send id of Create record -->
                                    	<input type="submit" name="submit" value="Submit" class="btn btn-dark btn-lg" style="margin-left: 240px;" onclick="return confirm('Do you want to submit?')"/> 
                                    </td>
                                </tr>
                        </form>
                    </td>
                </tr>

				</div>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
    <?php 

$sql = "SELECT * FROM items_categories Order by Category_ID"; // Assign SQL Statement to variable $sql
$result = $link->query($sql);
// Use query() function with $sql , variable $conn comes from connection.php
// Outcome from query() is assigned to variable $result

?>
<div class="mb-3">
            <div class="card-header clearfix">
                <h2 class="pull-left">Category Details</h2>
            </div>

            <tr>
                <td>
                    <table width="100%" cellspacing="5" cellpadding="5" class="table table-hover table-bordered">
                        <tr style="text-align: center;">
                            <th>Category ID</th>
                            <th>Category Name</th>
                            
                        </tr>

                        <?php
                                // If it has data in memebers table, show the data.
                        if ($result->num_rows > 0) {
                            $i = 1;
                                    while($row = $result->fetch_assoc()){ // Loop While สำหรับดึงข้อมูลจากฐานข้อมูล โดยใช้ Function fetch_assoc()
                                        ?>
                                        <!-- // Show the reault of Query via variable $row by echo command -->
                                        <tr style="text-align: center;">
                                            <td><?php echo $row['Category_ID'];?></td>
                                            <td><?php echo $row['Category_Name'];?></td>
                                           
                                        </tr>
                                        <?php
                                        $i++;
                                    }
                                }                               
                                ?>
                            </table>
                        </td>
                    </tr>
                </div>
</div>

<?php include ('includes/footer.php'); ?>