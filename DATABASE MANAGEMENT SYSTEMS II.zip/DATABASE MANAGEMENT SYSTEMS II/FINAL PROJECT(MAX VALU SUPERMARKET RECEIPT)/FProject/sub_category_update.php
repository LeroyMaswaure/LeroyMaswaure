<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

$Sub_Category_ID = $_GET['id']; // Receive id from index.php by $_GET

// Data Query by id
$sql = "SELECT * FROM items_sub_categories WHERE Sub_Category_ID ='{$Sub_Category_ID}'";
$result = $link->query($sql);
$row = $result->fetch_assoc();


?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Sub Category</li>
        </ol>

        <!-- DataTables Employees -->
        <div class="card mb-3">
            <div class="card-header clearfix">
                <h2>Update Sub Category</h2>
                <a href="sub_category.php" class="btn btn-info"; style="margin-left: 92%;">Return To List</a>
            </div>

            <div class="card-body">
                <div class="table-responsive">
               <tr>
                    <td>
                        <form name="update_sub_category" method="post" action="includes/sub_category_update_connection.php">
                            <table width="100%" cellspacing="5" cellpadding="5" class="table table-borderless">
                                 <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">Sub Category Name:</td>
                                    <td><input type="text" name="Sub_Category_Name" style="width: 250px; height: 30px;" value="<?php echo $row['Sub_Category_Name'];?>"/></td>
                                </tr>      

                                <tr>
                                    <td style="width: 200px; text-align: right; font-weight: bold;">Category ID:</td>
                                    <td><input type="text" name="Category_ID" style="width: 250px; height: 30px;" value="<?php echo $row['Category_ID'];?>"/></td>
                                </tr>  

                            </table>   

                               <tr>
                                    <td style="width: 120px; text-align: right;"></td>

                                    <td>
                                        <input type="hidden" name="id" value="<?php echo $row['Sub_Category_ID'];?>" /><!-- Send id of update record -->
                                        <input type="submit" name="submit" value="Submit" class="btn btn-dark btn-lg" style="margin-left: 210px;" onclick="return confirm('Do you want to submit?')"/> 
                                    </td>
                                </tr>
                        </form>
                    </td>
                </tr>

                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>