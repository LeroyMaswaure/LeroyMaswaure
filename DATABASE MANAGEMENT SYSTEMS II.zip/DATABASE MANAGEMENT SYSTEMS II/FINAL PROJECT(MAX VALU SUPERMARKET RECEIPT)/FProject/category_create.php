<?php include ('includes/header.php'); ?>
<?php include ("includes/config.php");

?>

<div id="content-wrapper">
	<div class="container-fluid">
		<!-- Breadcrumbs-->
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="#">Dashboard</a>
			</li>
			<li class="breadcrumb-item active">Category</li>
		</ol>

		<!-- DataTables Employees -->
		<div class="card mb-3">
			<div class="card-header clearfix">
				<h2>Add New Category</h2>
				<a href="category.php" class="btn btn-info"; style="margin-left: 92%;">Return To List</a>
			</div>

			<div class="card-body">
				<div class="table-responsive">
               <tr>
                    <td>
                        <form name="create_category" method="post" action="includes/category_create_connection.php">
                            <table width="100%" cellspacing="5" cellpadding="5" class="table table-borderless">

                                 <tr>
                                    <td style="width: 230px; text-align: right; font-weight: bold;">Category Name:</td>
                                    <td><input type="text" name="Category_Name" style="width: 250px; height: 30px;"/></td>
                                </tr>
                             
                            </table>   

                               <tr>
                                    <td style="width: 230px; text-align: right;"></td>
                                    <td>
                                        <input type="hidden" name="Category_ID" value="<?php echo $row['Category_ID'];?>" /><!-- Send id of Create record -->
                                    	<input type="submit" name="submit" value="Submit" class="btn btn-dark btn-lg" style="margin-left: 240px;" onclick="return confirm('Do you want to submit?')"/> 
                                    </td>
                                </tr>
                        </form>
                    </td>
                </tr>

				</div>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
</div>

<?php include ('includes/footer.php'); ?>