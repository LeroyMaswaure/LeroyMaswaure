-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2020 at 11:03 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pro1`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `Branch_ID` int(11) NOT NULL,
  `Branch_Name` varchar(30) NOT NULL,
  `Branch_Address` varchar(40) NOT NULL,
  `Branch_City` varchar(30) NOT NULL,
  `Branch_Phone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`Branch_ID`, `Branch_Name`, `Branch_Address`, `Branch_City`, `Branch_Phone`) VALUES
(1, 'PATTANAKARN', '2559 Pattanakarn Rd', 'Bangkok', '0-2322-7003-4'),
(2, 'RAMA 9 THE NINE', '999/1 Rama 9 Rd.', 'Bangkok', '0-2318-5118-9'),
(3, 'PATTANAKARN 20', '206 Soi Pattanakarn 20', 'Bangkok', '0-2318-6893-4'),
(4, 'Pasio', '245 Bangkapi', 'Bangkok', '0-2455-7003-4');

-- --------------------------------------------------------

--
-- Table structure for table `cashier`
--

CREATE TABLE `cashier` (
  `Cashier_ID` int(11) NOT NULL,
  `FName` varchar(15) NOT NULL,
  `M_Name` varchar(20) NOT NULL,
  `L_Name` varchar(20) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `cashier`
--

INSERT INTO `cashier` (`Cashier_ID`, `FName`, `M_Name`, `L_Name`, `Username`, `Password`) VALUES
(1, 'Yen', 'Hai', 'Nguyen', 'admin', 'admin'),
(6, 'shekina', 'munyiu', 'kadiongo', 'kads', '$2y$10$ON1RcUMj2BdqW9PA8T'),
(7, 'lee', 'roy', '', 'lee', '$2y$10$VecI4B9TTaa8BA9Ong');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `Customer_ID` int(11) NOT NULL,
  `Customer_FName` varchar(20) DEFAULT NULL,
  `Customer_MName` varchar(20) DEFAULT NULL,
  `Customer_LName` varchar(20) DEFAULT NULL,
  `Member_registration_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`Customer_ID`, `Customer_FName`, `Customer_MName`, `Customer_LName`, `Member_registration_date`) VALUES
(1, 'Anonymous', '', '', '2019-12-01'),
(2, 'Hoan', 'Thi', 'Ngo', '2018-05-11'),
(3, 'Thao', 'Phuong', 'Le', '2018-10-07'),
(4, 'shek', 'kads', 'mu', '2020-01-01'),
(5, 'bob', 'kdan', 'mat', '2020-02-01');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `Transaction_ID` int(11) NOT NULL,
  `Transaction_Date` date NOT NULL,
  `Transaction_time` time NOT NULL,
  `Terminal_ID` int(11) NOT NULL,
  `Cashier_ID` int(11) NOT NULL,
  `Customer_ID` int(11) DEFAULT NULL,
  `Customer_EarnPoint` int(11) DEFAULT NULL,
  `Payment_Type` enum('Cash','Debit/Credit Card') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`Transaction_ID`, `Transaction_Date`, `Transaction_time`, `Terminal_ID`, `Cashier_ID`, `Customer_ID`, `Customer_EarnPoint`, `Payment_Type`) VALUES
(1, '2020-01-26', '20:06:07', 1, 1, 1, 0, 'Cash'),
(2, '2020-02-26', '21:06:07', 2, 1, 3, 1, 'Cash'),
(3, '2021-02-10', '15:10:07', 3, 1, 2, 10, 'Debit/Credit Card');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_details`
--

CREATE TABLE `invoice_details` (
  `Transaction_ID` int(11) NOT NULL,
  `Item_ID` int(11) NOT NULL,
  `order_item_quantity` int(11) NOT NULL,
  `order_item_price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `invoice_details`
--

INSERT INTO `invoice_details` (`Transaction_ID`, `Item_ID`, `order_item_quantity`, `order_item_price`) VALUES
(1, 1, 10, '32.00'),
(2, 2, 12, '23.00'),
(3, 3, 10, '45.00');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `Item_ID` int(11) NOT NULL,
  `Sub_Category_ID` int(11) NOT NULL,
  `Item_Name` varchar(150) NOT NULL,
  `Unit_Price` decimal(10,2) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`Item_ID`, `Sub_Category_ID`, `Item_Name`, `Unit_Price`, `Quantity`) VALUES
(1, 1, 'Banana Pack 4', '32.00', 101),
(2, 1, 'Kinri Watermelon per KG', '23.00', 150),
(3, 1, 'Cucumber per Pack\r\n', '15.00', 50),
(4, 1, 'TIPCO Squeeze Fuji Apple & Mixed Grape Juice 1 L', '87.00', 100),
(5, 1, 'Green Apple No.163 Pack 6', '59.00', 50),
(6, 2, 'Big C Minced Pork Grade A per KG\r\n', '170.00', 50),
(7, 2, 'Nile Tilapia Size XL (0.5-1 KG/PC) per PC\r\n', '69.00', 50),
(8, 2, 'Pork Spare Ribs per KG\r\n', '180.00', 50),
(9, 2, 'Big C Minced Chicken Fillet per KG\r\n', '110.00', 50),
(10, 3, 'JPM Sausage Gold Vienna Pork & Chicken Sausage 320 G.\r\n', '49.00', 100),
(11, 3, 'CASINO Emmental Cheese 300 G\r\n', '225.00', 50),
(12, 3, 'Philadelphia Cream Cheese Original Block 250 G\r\n', '119.00', 50),
(13, 3, 'BMP Smoked Bacon 150 G\r\n', '89.00', 100),
(14, 3, 'TGM Roast Ham 140 G\r\n', '49.00', 100),
(15, 4, 'JADE DRAGON Cream Bun 333 G\r\n', '72.00', 125),
(46, 6, 'Bonbon', '70.00', 120);

-- --------------------------------------------------------

--
-- Table structure for table `items_categories`
--

CREATE TABLE `items_categories` (
  `Category_ID` int(11) NOT NULL,
  `Category_Name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `items_categories`
--

INSERT INTO `items_categories` (`Category_ID`, `Category_Name`) VALUES
(3, 'Beverages'),
(2, 'Food'),
(1, 'Fresh Food'),
(4, 'Snack & Sweets');

-- --------------------------------------------------------

--
-- Table structure for table `items_sub_categories`
--

CREATE TABLE `items_sub_categories` (
  `Category_ID` int(11) DEFAULT NULL,
  `Sub_Category_ID` int(11) NOT NULL,
  `Sub_Category_Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `items_sub_categories`
--

INSERT INTO `items_sub_categories` (`Category_ID`, `Sub_Category_ID`, `Sub_Category_Name`) VALUES
(1, 1, 'Vegetable & Fruit'),
(1, 2, 'Meat & Seafood'),
(1, 3, 'Cheese & Sausage'),
(1, 4, 'Frozen'),
(1, 5, 'Bakery'),
(2, 6, 'Cooking Ingredients'),
(2, 7, 'Import Product'),
(2, 8, 'Rice/ Grains / Herbs/ Dry Fruits'),
(3, 9, 'Soft Drink'),
(3, 10, 'Water'),
(4, 11, 'Snack'),
(4, 12, 'Chocolate/ Sweet');

-- --------------------------------------------------------

--
-- Stand-in structure for view `loyolalty_point_card`
-- (See below for the actual view)
--
CREATE TABLE `loyolalty_point_card` (
);

-- --------------------------------------------------------

--
-- Table structure for table `tbllogactivity`
--

CREATE TABLE `tbllogactivity` (
  `logDateTime` datetime NOT NULL COMMENT 'Date and Time of Activity',
  `logActivity` varchar(45) DEFAULT NULL COMMENT 'Activity : Insert / Update / Delete',
  `logTableName` varchar(45) DEFAULT NULL COMMENT 'Table Activity\n',
  `logDetail` varchar(255) DEFAULT NULL COMMENT 'Detail of the activity',
  `logUser` varchar(20) DEFAULT NULL COMMENT 'User who do an activity.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='This table keeps activities of users' ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tbllogactivity`
--

INSERT INTO `tbllogactivity` (`logDateTime`, `logActivity`, `logTableName`, `logDetail`, `logUser`) VALUES
('2020-02-05 15:32:26', 'INSERT', 'users', 'NEW ROW : zxc/asdfgh/0000-00-00 00:00:00', 'root@localhost');

-- --------------------------------------------------------

--
-- Table structure for table `terminal`
--

CREATE TABLE `terminal` (
  `Terminal_ID` int(11) NOT NULL,
  `Terminal_Num` int(11) NOT NULL,
  `Branch_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `terminal`
--

INSERT INTO `terminal` (`Terminal_ID`, `Terminal_Num`, `Branch_ID`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 1),
(9, 6, 1),
(10, 7, 1),
(12, 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'kads1', '$2y$10$IhsPPlhRQGQDlCe9dUFTEOJSt0IMC7KcYFvz/6plpW7KfcZgJiw2G', '2020-02-04 20:14:32'),
(100, 'zxc', 'asdfgh', '0000-00-00 00:00:00');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `DeleteActivityUsers` BEFORE DELETE ON `users` FOR EACH ROW BEGIN
	INSERT INTO TBLLOGACTIVITY (logDateTime,logActivity,logTableName,logDetail,logUser)
    VALUES (NOW(),'DELETE','users',CONCAT('DELETE ROW : ',OLD.username,'/',OLD.password,'/',OLD.created_at),CURRENT_USER);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `InsertActivityUsers` AFTER INSERT ON `users` FOR EACH ROW BEGIN
	INSERT INTO TBLLOGACTIVITY (logDateTime,logActivity,logTableName,logDetail,logUser)
    VALUES (NOW(),'INSERT','users',CONCAT('NEW ROW : ',NEW.username,'/',NEW.password,'/',NEW.created_at), CURRENT_USER);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `UpdateActivityUsers` AFTER UPDATE ON `users` FOR EACH ROW BEGIN
	INSERT INTO TBLLOGACTIVITY (logDateTime,logActivity,logTableName,logDetail,logUser)
    VALUES (NOW(),'UPDATE','users',CONCAT('UPDATE ROW : ','id OLD-NEW: ',OLD.id,'-',NEW.id,'/',
    'username OLD-NEW: ',OLD.username,'-',NEW.username,'/','password OLD-NEW: ',OLD.password,'-',NEW.password,'/' ,
    'create_at OLD-NEW: ',OLD.created_at,'-',NEW.created_at),CURRENT_USER);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `vat`
--

CREATE TABLE `vat` (
  `id` int(11) NOT NULL,
  `Year` year(4) NOT NULL,
  `Percentage` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `vat`
--

INSERT INTO `vat` (`id`, `Year`, `Percentage`) VALUES
(1, 2019, 7),
(2, 2020, 7);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_invoice`
-- (See below for the actual view)
--
CREATE TABLE `view_invoice` (
`Transaction_ID` int(11)
,`Transaction_Date` date
,`Transaction_time` time
,`Terminal_ID` int(11)
,`Fname` varchar(15)
,`Customer_FName` varchar(20)
,`Customer_EarnPoint` int(11)
,`Payment_Type` enum('Cash','Debit/Credit Card')
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_invoice_details`
-- (See below for the actual view)
--
CREATE TABLE `view_invoice_details` (
`Transaction_ID` int(11)
,`Item_Name` varchar(150)
,`Percentage` int(10)
,`order_item_quantity` int(11)
,`order_item_price` decimal(10,2)
,`Name_exp_6` decimal(22,3)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_items`
-- (See below for the actual view)
--
CREATE TABLE `view_items` (
`Item_ID` int(11)
,`Item_Name` varchar(150)
,`Sub_Category_Name` varchar(100)
,`Unit_Price` decimal(10,2)
,`Quantity` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_items_sub_categories`
-- (See below for the actual view)
--
CREATE TABLE `view_items_sub_categories` (
`Sub_Category_ID` int(11)
,`Sub_Category_Name` varchar(100)
,`Category_Name` varchar(20)
);

-- --------------------------------------------------------

--
-- Structure for view `loyolalty_point_card`
--
DROP TABLE IF EXISTS `loyolalty_point_card`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `loyolalty_point_card`  AS  select `invoice`.`Transaction_ID` AS `Transaction_ID`,`customers`.`Customer_FName` AS `Customer_FName`,`customers`.`Customer_MName` AS `Customer_MName`,`invoice`.`Customer_EarnPoint` AS `Customer_EarnPoint`,`customers`.`Balance_Points` AS `Balance_Points`,`invoice`.`Customer_EarnPoint` + `customers`.`Balance_Points` AS `(invoice.Customer_EarnPoint +customers.Balance_Points)` from (`invoice` join `customers`) where `invoice`.`Customer_ID` = `customers`.`Customer_ID` order by `invoice`.`Transaction_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `view_invoice`
--
DROP TABLE IF EXISTS `view_invoice`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_invoice`  AS  select `invoice`.`Transaction_ID` AS `Transaction_ID`,`invoice`.`Transaction_Date` AS `Transaction_Date`,`invoice`.`Transaction_time` AS `Transaction_time`,`terminal`.`Terminal_ID` AS `Terminal_ID`,`cashier`.`FName` AS `Fname`,`customers`.`Customer_FName` AS `Customer_FName`,`invoice`.`Customer_EarnPoint` AS `Customer_EarnPoint`,`invoice`.`Payment_Type` AS `Payment_Type` from (((`invoice` join `terminal`) join `cashier`) join `customers`) where `invoice`.`Cashier_ID` = `cashier`.`Cashier_ID` and `invoice`.`Customer_ID` = `customers`.`Customer_ID` and `invoice`.`Terminal_ID` = `terminal`.`Terminal_ID` order by `invoice`.`Transaction_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `view_invoice_details`
--
DROP TABLE IF EXISTS `view_invoice_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_invoice_details`  AS  select `invoice_details`.`Transaction_ID` AS `Transaction_ID`,`items`.`Item_Name` AS `Item_Name`,`vat`.`Percentage` AS `Percentage`,`invoice_details`.`order_item_quantity` AS `order_item_quantity`,`invoice_details`.`order_item_price` AS `order_item_price`,`invoice_details`.`order_item_quantity` * `invoice_details`.`order_item_price` * 0.7 AS `Name_exp_6` from (((`invoice_details` join `invoice`) join `items`) join `vat`) where `invoice_details`.`Transaction_ID` = `invoice`.`Transaction_ID` and `invoice_details`.`Item_ID` = `items`.`Item_ID` order by `invoice_details`.`Transaction_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `view_items`
--
DROP TABLE IF EXISTS `view_items`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_items`  AS  select `items`.`Item_ID` AS `Item_ID`,`items`.`Item_Name` AS `Item_Name`,`items_sub_categories`.`Sub_Category_Name` AS `Sub_Category_Name`,`items`.`Unit_Price` AS `Unit_Price`,`items`.`Quantity` AS `Quantity` from (`items` join `items_sub_categories`) where `items`.`Sub_Category_ID` = `items_sub_categories`.`Sub_Category_ID` order by `items`.`Sub_Category_ID` ;

-- --------------------------------------------------------

--
-- Structure for view `view_items_sub_categories`
--
DROP TABLE IF EXISTS `view_items_sub_categories`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_items_sub_categories`  AS  select `items_sub_categories`.`Sub_Category_ID` AS `Sub_Category_ID`,`items_sub_categories`.`Sub_Category_Name` AS `Sub_Category_Name`,`items_categories`.`Category_Name` AS `Category_Name` from (`items_sub_categories` join `items_categories`) where `items_sub_categories`.`Category_ID` = `items_categories`.`Category_ID` order by `items_sub_categories`.`Category_ID` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`Branch_ID`) USING BTREE,
  ADD UNIQUE KEY `AK_br` (`Branch_Name`);

--
-- Indexes for table `cashier`
--
ALTER TABLE `cashier`
  ADD PRIMARY KEY (`Cashier_ID`) USING BTREE,
  ADD UNIQUE KEY `AK_PW` (`Username`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`Customer_ID`) USING BTREE;

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`Transaction_ID`) USING BTREE,
  ADD KEY `ter_invoice_fk` (`Terminal_ID`) USING BTREE,
  ADD KEY `cashier_invoice_fk` (`Cashier_ID`) USING BTREE,
  ADD KEY `customer_invoice_fk` (`Customer_ID`) USING BTREE;

--
-- Indexes for table `invoice_details`
--
ALTER TABLE `invoice_details`
  ADD PRIMARY KEY (`Transaction_ID`,`Item_ID`) USING BTREE,
  ADD KEY `item_invoice_fk` (`Item_ID`) USING BTREE;

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`Item_ID`) USING BTREE,
  ADD UNIQUE KEY `AK_I` (`Item_Name`),
  ADD KEY `sub_category_item_fk` (`Sub_Category_ID`) USING BTREE;

--
-- Indexes for table `items_categories`
--
ALTER TABLE `items_categories`
  ADD PRIMARY KEY (`Category_ID`) USING BTREE,
  ADD UNIQUE KEY `AK_IC` (`Category_Name`);

--
-- Indexes for table `items_sub_categories`
--
ALTER TABLE `items_sub_categories`
  ADD PRIMARY KEY (`Sub_Category_ID`) USING BTREE,
  ADD UNIQUE KEY `AK_ISC` (`Sub_Category_Name`),
  ADD KEY `category_sub_fl` (`Category_ID`) USING BTREE;

--
-- Indexes for table `tbllogactivity`
--
ALTER TABLE `tbllogactivity`
  ADD PRIMARY KEY (`logDateTime`) USING BTREE;

--
-- Indexes for table `terminal`
--
ALTER TABLE `terminal`
  ADD PRIMARY KEY (`Terminal_ID`) USING BTREE,
  ADD UNIQUE KEY `AK_IC` (`Terminal_Num`),
  ADD KEY `branch_terminal_fk` (`Branch_ID`) USING BTREE;

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `vat`
--
ALTER TABLE `vat`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `AK_VT` (`Year`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `Branch_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `cashier`
--
ALTER TABLE `cashier`
  MODIFY `Cashier_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `Customer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `Transaction_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `Item_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `items_categories`
--
ALTER TABLE `items_categories`
  MODIFY `Category_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `items_sub_categories`
--
ALTER TABLE `items_sub_categories`
  MODIFY `Sub_Category_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `terminal`
--
ALTER TABLE `terminal`
  MODIFY `Terminal_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `vat`
--
ALTER TABLE `vat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoice`
--
ALTER TABLE `invoice`
  ADD CONSTRAINT `cashier_invoice_fl` FOREIGN KEY (`Cashier_ID`) REFERENCES `cashier` (`Cashier_ID`),
  ADD CONSTRAINT `customer_invoice_fl` FOREIGN KEY (`Customer_ID`) REFERENCES `customers` (`Customer_ID`),
  ADD CONSTRAINT `pos_invoice_fk` FOREIGN KEY (`Terminal_ID`) REFERENCES `terminal` (`Terminal_ID`);

--
-- Constraints for table `invoice_details`
--
ALTER TABLE `invoice_details`
  ADD CONSTRAINT `item_invoice_fk` FOREIGN KEY (`Item_ID`) REFERENCES `items` (`Item_ID`),
  ADD CONSTRAINT `transaction_invoice_fk` FOREIGN KEY (`Transaction_ID`) REFERENCES `invoice` (`Transaction_ID`);

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `sub_category_item_fk` FOREIGN KEY (`Sub_Category_ID`) REFERENCES `items_sub_categories` (`Sub_Category_ID`);

--
-- Constraints for table `items_sub_categories`
--
ALTER TABLE `items_sub_categories`
  ADD CONSTRAINT `category_fk` FOREIGN KEY (`Category_ID`) REFERENCES `items_categories` (`Category_ID`);

--
-- Constraints for table `terminal`
--
ALTER TABLE `terminal`
  ADD CONSTRAINT `branch_terminal_fk` FOREIGN KEY (`Branch_ID`) REFERENCES `branch` (`Branch_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
