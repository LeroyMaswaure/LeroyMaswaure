document.write("")
var numberoffeatures = [
	"<=10",
	"<=50",
	">=50"
	

var price = [50000, 90000];
var discounted price = [37500,67500]; 
var numberoffeaturestext = "";
var productsElement = document.getElementById("product-list");

numberoffeaturestext = numberoffeaturestext + "" + numberoffeatures[0] + "<span class='badge badge-secondary'>$" + price[0] + "";