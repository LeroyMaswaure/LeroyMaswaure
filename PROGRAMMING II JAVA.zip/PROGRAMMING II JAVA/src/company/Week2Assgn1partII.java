package company;

import java.util.Arrays;

public class Week2Assgn1partII {
    public static void main(String[] args) {
        String[] arr = {"Fire", "Ice", "Earth", "Lightning", "Wind"};

        String[] multispell = Attack(arr);
        out(Arrays.toString(multispell));

    }

    public static String[] Attack(String[] arr) {
        int n = arr.length;
        String[] newArray = new String[n];

        String CAST = " Cast ";
        String SPELL = " ball!!! ";

        for (int j = 0; j < arr.length; j++) {

            newArray[j] = CAST + arr[j] + SPELL;
        }
        return newArray;
    }


    public static void out(Object o){
        System.out.println(o.toString());
    }
}

