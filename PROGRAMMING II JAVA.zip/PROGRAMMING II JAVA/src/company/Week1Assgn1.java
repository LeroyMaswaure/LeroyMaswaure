package company;
public class Week1Assgn1 {
    public static void main(String[] args) {
        int a = 1;
        int b = 2;
        int c = 3;
        int d = 1;

        System.out.println("Number"+d++);
        System.out.println(a++);
        System.out.println("Number"+d++);
        System.out.println(++c);
        System.out.println("Number"+d++);
        System.out.println(a+c--);
        System.out.println("Number"+d++);
        --c;
        --c;
        System.out.println(true);
        System.out.println("Number"+d++);
        System.out.println(false);
        System.out.println("Number"+d++);
        System.out.println(false);
        System.out.println("Number"+d++);
        System.out.println(true);
        System.out.println("Number"+d++);
        System.out.println(b < a);
        System.out.println("Number"+d++);
        System.out.println(false);

    }
}


