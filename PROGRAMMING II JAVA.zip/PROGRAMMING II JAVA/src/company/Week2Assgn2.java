public interface Health {
    int health(int h);
}

public abstract class Character implements Health {
    protected double mp, hp;

    protected String characterName;

    private int limit = 100;

    private int health = 100;

    abstract public void attack(character c);

    /**
     * @param health method takes one parameter.
     * @return returns the output of the charaters health.
     */
    @Override
    public int health(int h) {
        return this.health = this.health - h;
    }

    protected Character(String characterName, int hp, int mp) {
        this.characterName = characterName;
        this.hp = hp;
        this.mp = mp;

    }

    public String toString() {
        return this.characterName + " HP is " + this.hp + ", MP is " + this.mp + "\n" + this.characterName + " ";
    }

    public int getHP() {
        return this.hp;
    }

    public int getMP() {
        return this.mp;
    }

    public void setHP(int hp) {
        if (hp >= 1 && hp <= this.limit) {
            this.hp = hp;
            System.out.println("HP is now " + this.hp);
        } else {
            System.out.println("HP cannot be lower than 1");
        }
    }

    public void setMP(int mp) {
        if (mp >= 1 && mp <= this.limit) {
            this.mp = mp;
            System.out.println("MP is now " + this.mp);
        } else {
            System.out.println("MP cannot be lower than 1");
        }
    }

}
