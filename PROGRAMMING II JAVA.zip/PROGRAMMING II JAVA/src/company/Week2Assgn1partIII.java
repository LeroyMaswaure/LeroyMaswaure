package test;

public class Week2Assgn1partIII {

    public int MP;
    public int HP;


    public void heal(int hp) {

    }

    public void attack(int speed) {

    }
}
