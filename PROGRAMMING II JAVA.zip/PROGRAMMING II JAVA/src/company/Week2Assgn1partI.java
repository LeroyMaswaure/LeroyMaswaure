package company;

public class Week2Assgn1partI {
    public static void main(String[] args) {
        String attack_string = Attack("slash","head");

        System.out.println("Attack with " + attack_string);

        String attack2_string = Attack("bow", "eye");

        System.out.println("Attack with "+ attack2_string);
    }

    public static String Attack(String str1, String str2) {
        return str1 + " in the " + str2;
    }
}


